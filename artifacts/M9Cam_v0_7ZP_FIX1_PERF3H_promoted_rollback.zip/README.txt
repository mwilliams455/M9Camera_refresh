M9Cam v0.7ZP PRIMARY2.5 PERF3H CVDIRECT1A + ORIENTFUSE8A + EXIFASYNC1A + JPEGBUF64K1A + TC20LUMA8A + COLOR8A

Direct derivative of device-validated/promoted v0.7ZO PERF3G ORIENTFUSE8A.

PERF3H execution change only:
- Keep the exact same OpenCV 16-bit demosaic result and frozen scalar M9 photographic kernel.
- For the TC20 meter and full-color input, use OpenCV Mat.dataAddr() only when the Mat is verified packed/continuous CV_16U 3-channel storage:
  isContinuous=true, channels=3, elemSize1=2, step1=width*3, non-zero dataAddr.
- Native code reads that packed Mat synchronously during the JNI call.
- This removes the normal-path Mat.get(short[]) camera copy and the subsequent JNI GetShortArrayRegion camera copy.
- If any Mat layout check fails, automatically use the exact promoted Java-short-array copied-input path instead.
- Output remains the existing int[] -> Bitmap.setPixels path; PERF3H does NOT yet write Android Bitmap memory directly.

Quality/parity contract:
- 12 MP 3072x4096 JPEG unchanged.
- JPEG quality remains 95.
- Same Android Bitmap.compress encoder and 64 KiB transport buffer.
- Same EXIFASYNC1A and JPEG-before-DNG publication ordering.
- Same DNGASYNC1A RAW ownership/preservation architecture.
- ORIENTFUSE8A retained.
- Frozen R3.8 H25/TG1, Cobalt calibration, M9 bridge, TC20 selection/gain math, SAT3 M06/M07, curve02 and exact BT.601 horizontal 4:2:2 unchanged.
- No exposure changes, fast-math, NEON, encoder swap, quality reduction or render-resolution change.

Host validation:
- all six frozen native photographic-kernel hashes unchanged;
- actual renderStripScalar direct-pointer vs copied-input parity passed 15,316 block cases;
- TC20 weighted-selection direct-pointer vs copied-input parity passed 12 cases;
- m9color_jni.cpp host C++17 syntax check passed;
- M9NativeColorCore.java javac passed;
- PERF3H source guard passed.

Expected device signal on the normal direct path:
- meterInputMode=opencv_mat_dataaddr_direct1a
- meterCvDirectEligible=true
- meterCvDirectFallback=false
- nativeColorInputMode=opencv_mat_dataaddr_direct1a
- nativeColorCvDirectEligible=true
- nativeColorCvDirectBlocks=8 for a 3072-row / 384-row block render
- nativeColorCvFallbackBlocks=0
- nativeColorOpenCvTransferElapsedMsSum should collapse from roughly 10-17 ms toward near-zero address/branch overhead.
- nativeColorInputCopyElapsedMsSum should collapse from roughly 4-7 ms toward zero.
- meterTransferElapsedMs should collapse from roughly 8-14 ms toward near-zero.
- tc20NativeInputCopyElapsedMs should retain only the tiny row/column-weight copies rather than the meter camera buffer copy.

Test one settled standalone frame and then 4-5 rapid frames after cooling. Do not promote if any output, metadata, DNG, queue or photographic-quality regression appears.

PERF3H FIX1 NOTE
----------------
This package corrects one stale inherited verifier rule that required the legacy
OpenCV Mat.get(short[]) extraction to precede JNI. PERF3H intentionally uses a
guarded Mat.dataAddr() direct JNI path first and retains Mat.get(short[]) only as
a preservation fallback. Application/native payload is unchanged; verifier only.
