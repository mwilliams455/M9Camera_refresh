# DNGASYNC1A validation summary

## Direct base

Promoted `v0.7ZG TIMINGFREEZE1A VERIFYFIX1 + NAME1A + QUEUE1B`.

Device validation of TIMINGFREEZE1A showed the primary render worker now releases in roughly
1.12-1.25 s and no longer waits for `_M9_PRIMARY.json` SAF persistence. The remaining development
DNG save is roughly 0.45-0.50 s of that worker lifetime and does not affect photographic pixels.

## Why this build exists

`ImageSaver.Util.saveSingleRaw()` still consumes the owned Photon `ImageFrame`, so the RAW cannot
simply be closed at JPEG completion. DNGASYNC1A therefore transfers ownership rather than copying
or prematurely releasing it.

Normal accepted path:

1. `M9PrimaryRenderer` renders/saves the unchanged M9 JPEG first.
2. Renderer diagnostics are frozen to immutable JSON text.
3. The original Photon `ImageFrame` is handed nonblocking to dedicated daemon `M9PrimaryDngIO`.
4. QUEUE1B render in-flight accounting is decremented immediately; the next M9 render may start.
5. `M9PrimaryDngIO` saves the untouched development DNG using the same original frame.
6. METAFREEZE1A capture metadata persistence is scheduled after DNG completion.
7. Final PRIMARY timing JSON is frozen to immutable bytes with final `dngSaved`/DNG timing known.
8. The DNG worker closes the RAW frame.
9. `M9PrimaryTimingIO` persists only the immutable timing bytes asynchronously.

No RAW copy is introduced.

## Bounded memory / failure behavior

The DNG stage is intentionally small:

- one active DNG worker
- `DNG_MAX_PENDING = 1`
- at most one queued DNG frame behind the active DNG frame

If a third DNG handoff arrives while that bounded stage is saturated, the render worker performs
that DNG save synchronously instead of retaining another full RAW frame. This deliberately trades
throughput for correctness under abnormal storage pressure:

- DNG output is preserved
- RAW ownership remains bounded
- no unbounded executor is introduced
- no blocking queue `put()` is used
- every accepted frame still has one final owner/close path

## Timing schema

`m9cam.primarytiming.v5.dngasync1a`

Route:

`M9-PRIMARY2.4-TC20NATIVE1B-ORIENT1A-NORMNATIVE1A-METAFREEZE1A-COLORNATIVE2A-FIX1-NAME1A-QUEUE1B-TIMINGFREEZE1A-DNGASYNC1A`

New/audited fields include:

- `dngPersistMode`
- `dngAsyncAccepted`
- `dngAsyncFallbackSync`
- `dngQueueDepthAtHandoff`
- `dngActiveCountAtHandoff`
- `dngQueueCapacity`
- `dngHandoffElapsedMs`
- `dngQueueWaitElapsedMs`
- `dngFallbackCountSnapshot`
- `dngWorkerElapsedMs`
- `rawFrameCloseOwner`
- `primaryTimingFreezeThread`
- `workerElapsedBoundary = render_worker_elapsed_to_dng_handoff_or_sync_completion`

TIMINGFREEZE1A remains active: final PRIMARY timing is frozen before final RAW close, while SAF
persistence remains isolated on `M9PrimaryTimingIO`.

## Frozen photographic behavior

The following payloads are byte-for-byte identical to the promoted v0.7ZG base:

- `M9R35Renderer.java`
- `M9NativeColorCore.java`
- `m9color_jni.cpp`
- calibration asset/manifest
- `M9SubjectMotionAnalyzer.java`
- `M9DeferredMetadataStore.java`
- `M9CapturePathAllocator.java`

Only these runtime payload files changed:

- `M9PrimaryRenderQueue.java`
- `M9PrimaryTimingWriter.java`
- `M9BacklightDiagnostic.java` (build identity only)

Renderer schema remains frozen:

`m9cam.renderer.r38.h25tg1.full12.android.v19.primary2p4tc20native1borient1anormnative1acolornative2afix1`

Exposure, TC20, H25/HSM, SAT3, curve02, BT.601/TG1, ORIENT1A, NORMNATIVE1A,
COLORNATIVE2A FIX1, LUMA2.4-SPATIAL2-FB1, NAME1A and QUEUE1B are unchanged.

## Host/static validation

- patch script `py_compile`: PASS
- verifier `py_compile`: PASS
- queue/timing Java syntax with Android/Photon stubs: PASS
- DNGASYNC1A source guard: PASS
- renderer/native/calibration freeze hashes: PASS
- no second RAW copy: PASS
- bounded single DNG worker + one pending slot: PASS
- synchronous DNG fallback on DNG-stage saturation: PASS
- final PRIMARY timing freeze occurs before async RAW close: PASS
- METAFREEZE1A capture metadata remains after DNG persistence: PASS

### Behavioral scheduler test

Synthetic timings: JPEG render 120 ms, DNG save 450 ms, three accepted render jobs.

Observed:

- frame 2 render started at 161 ms
- frame 1 DNG completed at 612 ms
- therefore the next render started while the prior DNG was still being written: PASS
- bounded DNG queue saturation forced exactly one synchronous fallback: PASS
- every RAW frame closed exactly once: PASS
- render and DNG queues drained: PASS

### TIMINGFREEZE regression test

An artificial 2000 ms timing-storage stall was injected behind the SAF helper.
`freezeAndWriteAsync()` returned in 25 ms while async persistence took 2001 ms: PASS.

## Build identity

`1.23-m9modern7r38luma24fb1primary24tc20native1borient1anormnative1ametafreeze1acolornative2afix1name1aqueue1btimingfreeze1adngasync1a`

## Device gate

Use the same rapid burst test and collect logcat plus several `_M9_PRIMARY.json` files.

Expected normal path:

1. `DNGASYNC1A RAW ownership handoff accepted` occurs immediately after the M9 JPEG render.
2. `QUEUE1B DNGASYNC1A render worker released ... RAW owned by M9PrimaryDngIO; next render may start now`.
3. The next `starting PRIMARY2.4` can occur before the previous frame's `DNGASYNC1A complete` log.
4. `_M9_PRIMARY.json` reports `schema = m9cam.primarytiming.v5.dngasync1a`.
5. Normal frames report `dngAsyncAccepted=true`, `dngAsyncFallbackSync=false`, and both JPEG/DNG saved.
6. `workerElapsedMs` should move toward JPEG/render time rather than JPEG+DNG time; target is roughly
   0.7-0.9 s based on the promoted device measurements, subject to I/O/CPU contention on-device.
7. Queue waits should reduce further from the TIMINGFREEZE1A ~1.55-2.22 s burst range.
8. QUEUE1B shutter-side saturation/recovery must remain intact.
9. No crash/OOM and no missing DNG/JPEG pairs.

A small number of `dngAsyncFallbackSync=true` frames is acceptable only if storage cannot keep up.
Frequent fallback means the DNG worker priority/queue strategy needs revisiting rather than widening
RAW retention blindly.
