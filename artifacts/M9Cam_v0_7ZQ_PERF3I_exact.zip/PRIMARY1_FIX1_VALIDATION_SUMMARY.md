# PRIMARY1-FIX1 Validation Summary

## Scope

Package label: **v0.7Q PRIMARY1-FIX1**.

This build is a one-variable derivative of the device-tested v0.7P PRIMARY1 package.

The only application-source change is in:

```text
app/src/main/java/com/particlesdevs/photoncamera/m9/render/M9PrimaryTimingWriter.java
```

Change:

```text
Files.newOutputStream(timingPath)
    ->
SimpleStorageHelper.openOutputStreamByAbsPath(timingPath.toString())
```

The helper is the same Photon SAF-aware absolute-path output mechanism already used by the proven capture diagnostic writer. The writer now treats a null helper stream as an explicit IOException so failure remains visible in logcat instead of becoming an NPE.

## Frozen state

No application-source changes were made to renderer arithmetic, exposure feedback, ImageFrame ownership, queueing, DNG ordering, JPEG encoding, H25, S85/V100, M9 bridge, TC20, SAT3, curve02, BT.601, TG1, LUMA2.4-SPATIAL2, FB1, motion policy, JPEG quality, or the 1600-side TC20 reference.

Build identity intentionally remains:

```text
1.00-m9modern7r38luma24fb1primary1
```

so FIX1 is isolated to instrumentation persistence.

## Expected device result

After installation and one capture, the RAW directory should contain a capture-matched:

```text
IMG_...._M9_PRIMARY.json
```

with timing fields including:

```text
ownershipTransferElapsedMs
captureMetadataElapsedMs
queueWaitElapsedMs
renderElapsedMs
dngSaveElapsedMs
workerElapsedMs
```

and embedded renderer stage timing such as `fullColorRenderElapsedMs`.
