# LUMA2.4-SPATIAL2 diagnostic candidate — validation summary

## Bottom line

v0.7M is a **diagnostic-only** scorer revision built directly from v0.7L.
It keeps the frozen R3.8 H25/TG1 renderer, M9Modern v0.6.1 exposure/motion
policy, the LUMA2.2 scalar branches, and the +0.75 EV recommendation cap.
Exposure feedback remains OFF.

LUMA2.4 adds two spatial mechanisms from the existing orientation-aware 3x3
preview-Y instrumentation:

1. a bright-sky/high-contrast landscape protection derived from the historical
   191721 false-positive family;
2. a separate spatial foreground-starvation branch that can establish a
   backlight candidate even when absolute ISO*shutter energy is high.

## Exact v0.7L field evidence used for the new positive branch

Current independent captures:

```text
065330 positive:
  dark <=64                 0.3232
  q95                       189
  bright >=192              0.04123
  max H/V-third median span 101 Y
  span / q95                0.5344
  lowest H/V-third median   38 Y
  low / q95                 0.2011

065403 positive:
  dark <=64                 0.4845
  q95                       191
  bright >=192              0.04586
  max H/V-third median span 114 Y
  span / q95                0.5969
  lowest H/V-third median   24 Y
  low / q95                 0.1257

072515 negative:
  dark <=64                 0.4946
  q95                       118
  bright >=192              0.000434
  max H/V-third median span 28 Y
  span / q95                0.2373
  lowest H/V-third median   47 Y
  low / q95                 0.3983
```

The negative is globally just as dark as the 065403 positive, so dark occupancy
alone is not enough. The positives instead combine a meaningful highlight
population with strong displayed-space separation and a collapsed low region.

## Spatial foreground-starvation branch

Provisional smooth ramps:

```text
darkFractionLE64:       0.28 -> 0.35
q95:                    135  -> 175 Y
brightFractionGE192:    0.008 -> 0.035
max H/V median span/q95 0.30 -> 0.48
lowest H/V median/q95:  full <=0.28, zero >=0.40
```

The five scores are combined geometrically. This branch does **not** require low
preview exposure energy and does **not** use the center-body protection. That is
intentional: 065330 has centerMedianMinusGlobalMedian = +28 Y yet is a true
positive because the bright center belongs to the window/sill structure rather
than proving that the foreground is healthy.

A conservative dark-body floor is retained so bright-window geometry alone does
not establish a positive when the scene body is not sufficiently buried.

## SPATIAL2 landscape protection

Historical dual-proxy replay remains the basis for the 191721 protection:

```text
global bright >=192:          0.15 -> 0.20
share of bright tiles in top: 0.72 -> 0.90
top-row median spread / q95:  0.28 -> 0.55
```

The guard attenuates the ordinary relative branch and the new spatial branch.
It **never** attenuates catastrophic whole-preview-collapse evidence.

Historical proxy replay result retained from the preceding investigation:

```text
191721 negative landscape: guard ~0.99  -> should suppress false +0.75 EV
191728 positive:           guard 0.00   -> preserve positive
182446 outdoor negative:   guard ~0.95  -> protect
182457 catastrophic pos:   guard 0.00   -> catastrophic branch preserved
185844 genuine positive:   guard 0.00   -> preserve
```

Pre-v0.7L captures do not contain exact preview 3x3 values, so those guard values
remain proxy evidence rather than exact live-preview replay.

## Exact current field smoke result

The bundled exact-field regression gives:

```text
065330 positive: spatial score ~0.924 -> positive
065403 positive: spatial score  1.000 -> positive
072515 negative: spatial score  0.000 -> negative
```

## Promotion status

```text
v0.7M / LUMA2.4-SPATIAL2:
DIAGNOSTIC FIELD CANDIDATE

exposureFeedbackEnabled = false
appliedExposureCorrectionEv = 0
```

Next field goal: challenge the scorer with new independent positives and
negatives, especially a usable bright-sky/high-contrast outdoor negative. Only
after the diagnostic scorer survives that cycle should a live-feedback build be
created.

## Frozen scalar-lineage replay

Running the LUMA2.4 reference scorer on old pre-spatial JSONs leaves the spatial
branches neutral and reproduces the frozen LUMA2.2 decisions available locally:

```text
191728 genuine positive:      +0.750 EV
182457 catastrophic positive: +0.750 EV
182446 protected negative:    +0.000 EV
```

This is expected because pre-v0.7L JSON has no `spatial3x3`; LUMA2.4 therefore
falls back to the retained scalar branches. The separate proxy regression checks
that the 191721 landscape guard geometry is on the intended side of the new
thresholds until an exact live-preview-Y outdoor control is captured.
