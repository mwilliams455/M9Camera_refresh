# M9Cam v0.7ZH DNGASYNC1A-FIX1 — metadata descriptor cleanup

## Scope

This FIX1 is deliberately metadata-only. It is based directly on the promoted v0.7ZH DNGASYNC1A package validated on-device on 2026-09-01.

The regular capture `_M9.json` was still emitting the stale pre-DNGASYNC descriptor:

`developmentDngPersistence = primary_worker_after_jpeg`

That string described the old architecture and conflicted with the final `_M9_PRIMARY.json`/logcat evidence showing the untouched RAW being handed to bounded `M9PrimaryDngIO` after JPEG render.

FIX1 changes the early capture snapshot to report the configured policy accurately:

`developmentDngPersistence = bounded_async_single_worker_after_jpeg_with_sync_fallback`

The regular `_M9.json` remains an early/pre-worker snapshot. Final per-frame execution truth remains `_M9_PRIMARY.json`, including `dngAsyncAccepted`, `dngAsyncFallbackSync`, queue wait, DNG worker elapsed time, and RAW close owner.

## Runtime payload diff versus promoted v0.7ZH

Exactly **one runtime payload file** changed:

`app/src/main/java/com/particlesdevs/photoncamera/m9/render/M9R35Renderer.java`

Exactly **one source line** changed in that file:

- old: `d.put("developmentDngPersistence", "primary_worker_after_jpeg");`
- new: `d.put("developmentDngPersistence", "bounded_async_single_worker_after_jpeg_with_sync_fallback");`

No queue, DNG worker, timing writer, RAW ownership, renderer math, native code, exposure logic, calibration, or save behavior changed.

## Build identity

The app build identity remains the promoted DNGASYNC1A identity:

`1.23-m9modern7r38luma24fb1primary24tc20native1borient1anormnative1ametafreeze1acolornative2afix1name1aqueue1btimingfreeze1adngasync1a`

This is intentional: FIX1 does not alter the DNGASYNC1A runtime architecture or photographic result; it only corrects a diagnostic descriptor.

## Validation

- Python patch script syntax: PASS
- Python verifier syntax: PASS
- DNGASYNC1A source guard: PASS
- Verifier now asserts the new metadata policy is present and the stale literal is absent: PASS
- Runtime payload diff versus promoted v0.7ZH: exactly 1 file: PASS
- `M9R35Renderer.java` diff versus promoted v0.7ZH: exactly 1 removed + 1 added source line: PASS
- Renderer normalized back to the old descriptor is otherwise byte/text identical: PASS
- `M9NativeColorCore.java`: unchanged
- `m9color_jni.cpp`: unchanged
- calibration binary/manifest: unchanged
- `M9SubjectMotionAnalyzer.java`: unchanged
- `M9DeferredMetadataStore.java`: unchanged
- `M9CapturePathAllocator.java`: unchanged
- DNGASYNC1A bounded worker / synchronous preservation fallback semantics: unchanged
- TIMINGFREEZE1A semantics: unchanged
- QUEUE1B semantics: unchanged
- NAME1A semantics: unchanged

## Device expectation

No new performance validation is required for the runtime architecture because this FIX1 does not change it. A single new `_M9.json` is enough to confirm the cleanup; it should contain:

`"developmentDngPersistence": "bounded_async_single_worker_after_jpeg_with_sync_fallback"`

A corresponding `_M9_PRIMARY.json` should continue to use schema `m9cam.primarytiming.v5.dngasync1a` and remain the final execution record.
