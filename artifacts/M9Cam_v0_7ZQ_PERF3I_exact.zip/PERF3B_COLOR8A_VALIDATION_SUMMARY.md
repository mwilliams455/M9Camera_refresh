# M9Cam v0.7ZJ PRIMARY2.5 / PERF3B COLOR8A — Validation Summary

## Scope

PERF3B COLOR8A is a single-variable device performance experiment derived from PERF3A.
It keeps the promoted photographic renderer, single M9PrimaryRenderer, queueing, RAW ownership,
DNGASYNC1A, TIMINGFREEZE1A, METAFREEZE1A and exposure behavior frozen.

Only the COLORNATIVE2A internal native scalar worker cap changes:

```text
PERF3A: up to 4 workers
PERF3B: up to 8 workers
```

The 384-row block size, scalar pixel/pair kernel, H25/HSM, M9 bridge, SAT3, curve02,
BT.601 4:2:2, TG1, ORIENT1A and all calibration data are unchanged.

Build identity:

```text
1.25-m9modern7r38luma24fb1primary25perf3bcolor8adngasync1a
```

Experiment marker:

```text
PERF3B_COLOR8A
```

## Why this experiment follows PERF3A

Five PERF3A device PRIMARY sidecars produced these medians:

```text
queue wait                         1402 ms
render worker                        860 ms
render core                          621 ms
full COLORNATIVE2A                   383 ms
native colour worker wall            309.1 ms
native colour thread overhead          8.8 ms
OpenCV colour transfer                12.5 ms
JNI colour input copy                  5.1 ms
native orientation                    19.2 ms
JNI colour output copy                 4.6 ms
Bitmap direct commit                  23 ms
TC20 total                            165 ms
TC20 native                           128 ms
TC20 luma population                   76.0 ms
JPEG encode/write                     192 ms
```

The result rules out persistent thread reuse as the main next win: spawn/join overhead is only
about 9 ms median. The scalar colour workers themselves consume roughly 309 ms median and remain
the largest directly measured compute component.

The worker count is therefore the narrowest high-leverage experiment before changing scalar
arithmetic or introducing ARM64/NEON.

## DNG spike observed in PERF3A

One fifth frame had a development DNG write of about 2560 ms. This did not block the M9 render
worker: DNGASYNC1A accepted the handoff, fallback remained false, and the same frame's render
worker completed in about 956 ms. This is storage/I/O variance, not evidence against the current
render queue architecture.

## Host/static validation

PASS:

- production `m9color_jni.cpp` is byte-identical to PERF3A;
- frozen function hashes for applyHsm, cameraToSrgbLuma, cameraToM9, m9CurvePixel,
  renderStripScalar and orientCompletedStrip are unchanged;
- row-partition scalar parity test checks worker counts 1,2,3,4,7,8 against the sequential oracle;
- ARGB output and even/edge/nearWhite sums are exact for 8 workers;
- patcher and verifier Python files compile;
- PERF3A detailed timing telemetry is retained for direct device comparison.

## Device acceptance test

Take 4-5 normal/rapid consecutive frames and inspect `_M9_PRIMARY.json`.

Primary comparison fields:

```text
parallelColorWorkers
nativeColorWorkersUsed
fullColorRenderElapsedMs
nativeColorWorkerWallElapsedMsSum
nativeColorWorkerMaxElapsedMsSum
renderCoreElapsedMs
workerElapsedMs
queueWaitElapsedMs
jpegEncodeWriteElapsedMs
```

Also confirm:

```text
dngAsyncAccepted = true
dngAsyncFallbackSync = false
rawFrameCloseOwner = M9PrimaryDngIO
jpegSaved = true
dngSaved = true
performanceForensics = PERF3B_COLOR8A
```

## Promotion rule

Do not promote based on host parity alone. Promote the 8-worker setting only if device evidence
shows a material reduction in colour/render worker time without crash/OOM, DNG fallback growth,
or photographic-output regression.

If 8-worker scaling is weak, revert the cap to 4 and move next to exact-parity scalar-kernel
optimization / ARM64 profiling. If scaling is strong, keep the scalar kernel and then address TC20
luma population as the next independent target.
