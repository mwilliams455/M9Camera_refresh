# PRIMARY2.3 JNI1 FIX6 validation summary

## Root cause established from device logcat
The failing JNI APKs crash in `PhotonCamera.onCreate()` because `FlowNetNcnnProcessor` cannot load `libncnnMl.so`. The M9 renderer is never reached on those startup attempts.

The integration delta that caused this was identified in FIX1-FIX4: when the active checkout lacked an `externalNativeBuild` declaration, the overlay inserted one pointing to `app/src/main/cpp/CMakeLists.txt`. The active checkout's CMake file does not define `ncnnMl`, so enabling that CMake project changed PhotonCamera native packaging and produced an APK without the launch-critical library.

FIX5 intentionally refused to proceed when no existing `ncnnMl` CMake target could be located, confirming piggybacking is not valid for this checkout.

## FIX6 packaging architecture
FIX6 does not edit PhotonCamera native build wiring at all. It uses the Android NDK toolchain already installed on the GitHub runner to compile `m9color_jni.cpp` directly into conventional Android jniLibs paths:

- `app/src/main/jniLibs/arm64-v8a/libm9color.so`
- `app/src/main/jniLibs/armeabi-v7a/libm9color.so`

No `externalNativeBuild` block is added. No `CMakeLists.txt` is changed. No `ncnnMl` CMake target is assumed.

Compiler contract for each ABI:
- C++17
- `-O3`
- `-ffp-contract=off`
- `-fno-fast-math`
- static C++ runtime linkage
- 16 KiB maximum ELF page alignment

## Frozen image mathematics
The FIX6 source is derived from the FIX4 safe-JNI kernel. H25/HSM, M9 bridge, SAT3, curve02, exact BT.601 horizontal 4:2:2 arithmetic, TG1, worker count and 24-row strip geometry are unchanged.

The pre-existing scalar parity reference remains:
`7e21b6ae4a9557ae` across 99,716 rendered pixel-cases.

## Build identity
- route: `M9-PRIMARY2.3-JNI1-FIX6`
- version: `1.11-m9modern7r38luma24fb1primary23jni1fix6`
- schema: `m9cam.renderer.r38.h25tg1.full12.android.v14.primary2p3jni1fix6`

## First test
1. GitHub patch output must print two `FIX6 built app/src/main/jniLibs/.../libm9color.so` lines.
2. APK must launch without the prior `libncnnMl.so not found` crash.
3. Take one photo and check FIX6 native-load/context/first-strip logs.
4. If stable, take the two timing frames for native performance comparison.
