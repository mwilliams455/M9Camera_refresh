# PRIMARY2.4 TC20NATIVE1B ORIENT1A → NORMNATIVE1A validation summary

**Date:** 2026-09-01  
**Device:** Xiaomi 15 Ultra, main/rear wide  
**Incoming accepted branch:** `M9-PRIMARY2.4-TC20NATIVE1B-ORIENT1A`  
**Next test branch:** `M9-PRIMARY2.4-TC20NATIVE1B-ORIENT1A-NORMNATIVE1A`

## 1. ORIENT1A device result — PROMOTE

Two real-device captures validate ORIENT1A in both relevant orientation cases.

### IMG_20260901_070442 — cameraRotation 90

```text
output                         3072 x 4096
orientationElapsedMs                    0
directOrientedCommitElapsedMs          32
normalizeRawElapsedMs                 311
demosaicElapsedMs                      29
meterTc20ElapsedMs                    125
nativeTc20ElapsedMs                    96
fullColorRenderElapsedMs              313
renderCoreElapsedMs                   782
jpegEncodeWriteElapsedMs              168
renderElapsedMs                       979
workerElapsedMs                      1434
```

The portrait JPEG is correctly oriented. No mirror/transpose error is visible.

### IMG_20260901_070527 — cameraRotation 0

```text
output                         4096 x 3072
orientationElapsedMs                    0
directOrientedCommitElapsedMs          23
normalizeRawElapsedMs                 534
demosaicElapsedMs                      31
meterTc20ElapsedMs                    152
nativeTc20ElapsedMs                   124
fullColorRenderElapsedMs              292
renderCoreElapsedMs                  1023
jpegEncodeWriteElapsedMs              210
renderElapsedMs                      1280
workerElapsedMs                      1799
```

The landscape JPEG is correctly oriented.

### ORIENT1A conclusion

The former full-frame orientation pass was ~188-190 ms. It is now 0 ms. The direct oriented Bitmap commit costs only 23-32 ms and is already inside the colour-stage wall time.

Against the immediately preceding TC20NATIVE1B examples:

```text
low-normalize reference renderCore     953 ms -> 782 ms
high-normalize reference renderCore   1221 ms -> 1023 ms
```

The exact comparisons are different scenes, but normalization time is closely matched in each pair (297 vs 311 ms; 538 vs 534 ms), making the ~171-198 ms core reduction strong device evidence for the removed orientation pass.

**ORIENT1A is promoted.**

## 2. Why normalization is next

After ORIENT1A, RAW normalization is the largest variable core stage:

```text
070442 normalizeRawElapsedMs  311 ms
070527 normalizeRawElapsedMs  534 ms
```

Both frames are the same 4096x3072 RAW size and use the same four-worker Java implementation. The ~223 ms spread is therefore not explained by image dimensions. Scene-dependent clipped fractions are also both very small, so the large spread is more consistent with Java allocation / thread scheduling / GC / memory-bandwidth variability than with photographic content.

The outgoing Java path performs, per frame:

- a 12,582,912-pixel Java float normalization loop;
- four freshly-created Java worker threads;
- four private CFA histograms;
- a 25 MB `short[]` normalized frame;
- serial histogram reduction;
- unchanged Java `rawTail(...)` analysis.

## 3. NORMNATIVE1A change

NORMNATIVE1A moves only the expensive per-pixel RAW normalization and per-CFA histogram accumulation into the existing `m9color` JNI library.

```text
Photon direct RAW ByteBuffer
        ↓
one JNI call
        ↓
4 native disjoint row workers
        ↓
exact PRIMARY2 float normalization arithmetic
+ exact CFA plane histogram/clipped count
        ↓
one normalized short[] output copy
        ↓
UNCHANGED OpenCV EA demosaic
```

The Java `rawTail(...)` decision remains unchanged and consumes the exact same 4-plane histogram definition.

NORMNATIVE1A intentionally does **not** change:

- black/white level interpretation;
- CFA plane assignment;
- normalized 16-bit rounding definition;
- clipping definition;
- RAW-tail quantile/headroom math;
- OpenCV demosaic;
- TC20NATIVE1B;
- H25/HSM / M9 bridge / SAT3 / curve02 / BT.601 / TG1;
- ORIENT1A mapping;
- exposure/LUMA2.4-SPATIAL2-FB1;
- JPEG quality or DNG contents.

## 4. Exact normalization arithmetic

The frozen Java reference remains in `M9R35Renderer.normalizeRange(...)` and still hashes to:

```text
7ec1c0039fa0a4e26812eaa20c14cc5532d21495d6fde89ac726ad9ad0b431ee
```

The new native kernel mirrors:

```text
plane = (y & 1) * 2 + (x & 1)
rv = little-endian RAW16
if rv >= whiteLevel: clipped++
else: histogram[plane][rv]++

v = (rv - black[plane]) / max(1.0f, whiteLevel - black[plane])
v = clamp(v, 0, 1)
nv = floor(v * 65535.0f + 0.5f)
```

Production native arithmetic flags remain:

```text
-O3
-ffp-contract=off
-fno-fast-math
```

## 5. Host parity / smoke validation

### Java vs C++ arithmetic checksum

Deterministic 257x193 synthetic RAW with four CFA black levels:

```text
Java checksum  34bc7b2d7da0fd5f
C++ checksum   34bc7b2d7da0fd5f
clipped        10570 on both
pixels         49601
```

### Actual JNI bridge parity

The actual `normalizeRawDirect` JNI entry was compiled into `libm9color.so` and invoked from Java using a direct `ByteBuffer`.

```text
JNI checksum   34bc7b2d7da0fd5f
clipped        10570
workers        4
```

Result: **exact JNI normalization parity PASS**.

### Full 12 MP JNI smoke

Synthetic 4096x3072 direct-buffer frame:

```text
histogram + clipped count == 12,582,912 pixels
workers = 4
PASS
```

Host timing is not an Android performance claim, but confirms the full-frame allocation/copy path executes successfully.

### Existing TC20 regression

After adding NORMNATIVE1A, the actual JNI TC20NATIVE1B parity test remains exact:

```text
Java weighted median   0.46205609372066964
Native weighted median 0.46205609372066964
Java P98               0.82639677488795830
Native P98             0.82639677488795830
valid population       49082 both
```

### ORIENT1A regression

0/90/180/270 strip destination mapping still passes exact host parity after the normalization addition.

## 6. New diagnostics

```text
parallelNormalizeMode
  native_directbuffer_disjoint_row_ranges_histogram_reduce

nativeNormalizeCore
  true

nativeNormalizeMode
  directbuffer_scalar4_histogram_parity1a

nativeNormalizeLibrary
  m9color

nativeNormalizeRawElapsedMs
  Java wall time for the one JNI normalization call

nativeNormalizeComputeElapsedMs
  native workers + deterministic histogram reduction

nativeNormalizeOutputCopyElapsedMs
  normalized 12 MP short[] JNI output copy

nativeNormalizeWorkersUsed
  actual native worker count

nativeLibraryLoadElapsedMs
  lazy m9color load time, separated from normalizeRawElapsedMs
```

`normalizeRawElapsedMs` remains the high-level total including Java array allocation, the JNI normalization call, histogram reshape and unchanged `rawTail(...)`.

## 7. Build identity

```text
package:
M9Cam_v0_7ZB_TC20NATIVE1B_ORIENT1A_NORMNATIVE1A.zip

route:
M9-PRIMARY2.4-TC20NATIVE1B-ORIENT1A-NORMNATIVE1A

version:
1.16-m9modern7r38luma24fb1primary24tc20native1borient1anormnative1a

renderer schema:
m9cam.renderer.r38.h25tg1.full12.android.v17.primary2p4tc20native1borient1anormnative1a
```

## 8. Device acceptance gate

Take 2-3 ordinary frames. Include at least one portrait frame.

Upload:

```text
*_M9_PRIMARY.json
*_M9.json
JPEG useful for regression checking
```

Primary fields:

```text
normalizeRawElapsedMs
nativeNormalizeRawElapsedMs
nativeNormalizeComputeElapsedMs
nativeNormalizeOutputCopyElapsedMs
nativeNormalizeWorkersUsed
renderCoreElapsedMs
renderElapsedMs
```

Incoming Java-normalization reference:

```text
311 ms
534 ms
```

Initial interpretation:

```text
<= 250 ms   useful PASS
<= 180 ms   strong PASS
<= 120 ms   excellent PASS
```

The larger goal is not only lower average time but materially lower frame-to-frame variance.

Also confirm:

- JPEG and DNG save;
- orientation remains correct;
- `orientationElapsedMs == 0`;
- TC20 remains in its established ~100-150 ms device range;
- colour remains near ~290-315 ms;
- no change in finished-image appearance attributable to normalization.

## 9. Next decision

If NORMNATIVE1A passes, promote it. At that point the renderer core should have no remaining ~200 ms standalone transform stage. The next performance question becomes whether to attack JPEG encode/write or the ~1.9-2.0 s `captureMetadataElapsedMs` / shot-to-shot capture-side latency.
