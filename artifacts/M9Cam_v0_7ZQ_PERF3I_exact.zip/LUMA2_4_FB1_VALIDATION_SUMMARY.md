# LUMA2.4-SPATIAL2-FB1 validation summary

Build target: `0.97-m9modern7r38luma24fb1`

## Purpose

First bounded live-feedback derivative of the field-validated v0.7M LUMA2.4-SPATIAL2 classifier. Classifier thresholds and the +0.75 EV cap are unchanged. The only photographic change is that an eligible positive recommendation is now applied to the normalized Photon target energy before the existing M9Modern v0.6.1 motion-cap policy and Photon shutter-priority allocator.

## Ordering / audit contract

```text
platform preview AE
    -> normalized Photon target
    -> unmodified PhotonCurrent reference log
    -> LUMA2.4-SPATIAL2 live decision
    -> if eligible positive: target energy x 2^EV (EV <= +0.75)
    -> M9Modern v0.6.1 motion policy
    -> existing Photon shutter-priority allocator
    -> final ISO/shutter
```

`m9ExposureFeedback` records the decision-time classifier plus pre/post target exposure, normalized ISO and target energy.

## Safety gates

Feedback is applied only when all are true:

- actual capture allocation (`step >= 0`), never the internal `GenerateExpoPair(-1, ...)` frametime preflight;
- M9Modern PHOTO;
- handheld / non-tripod;
- user EV = 0;
- automatic shutter;
- automatic ISO;
- at least 3 preview-luma frames;
- valid orientation-aware spatial grid;
- LUMA2.4 `wouldApply = true`.

For the actual capture allocation, rotation is resolved directly from current Gravity + sensor orientation. This avoids relying on `CaptureController.cameraRotation`, which is assigned only after the preflight `GenerateExpoPair(-1, ...)` call in current PhotonCamera.

## Regression results

- LUMA2.2 independent 8-frame smoke regression: PASS
- LUMA2.3 frozen LUMA2.2 12-frame decision regression: PASS
- LUMA2.3 orientation mapping smoke: PASS
- LUMA2.4 exact-field spatial regression: PASS
  - 065330 positive -> apply
  - 065403 positive -> apply
  - 072515 negative -> no apply
  - 065131 bright-window control -> no apply
- LUMA2.4 historical 191721/191728 landscape proxy guard: PASS
- FB1 energy arithmetic:
  - 074858 positive -> +0.75 EV -> 1.68179283x target energy
  - 075124 negative -> +0.00 EV -> 1.0x target energy
- `M9BacklightDiagnostic.java` isolated Java syntax smoke: PASS
- v0.7N patch application against a v0.6.1-seam fixture: PASS
- semantic verifier: 70 checks PASS
- Python patch/verifier/reference syntax: PASS
- Frozen renderer/calibration/offline-reference files byte-identical to v0.7M: PASS
- All 39 LUMA2.4 numeric threshold constants byte-for-byte text-identical to v0.7M: PASS

## Not performed here

A complete Android/Gradle APK build was not performed in this environment. The GitHub build remains the compile/install gate.
