# M9Cam v0.7ZG TIMINGFREEZE1A VERIFYFIX1

## Scope
Verifier-only correction for the GitHub verification failure:

`FAIL PRIMARY1 timing uses Photon SAF storage helper`

TIMINGFREEZE1A moved accepted PRIMARY timing persistence into `persistFrozen(FrozenTiming frozen)`. The runtime writer correctly uses Photon SAF storage via:

`SimpleStorageHelper.openOutputStreamByAbsPath(frozen.timingPath.toString())`

The v0.7ZG verifier still required the pre-TIMINGFREEZE literal:

`SimpleStorageHelper.openOutputStreamByAbsPath(timingPath.toString())`

VERIFYFIX1 updates only that verifier assertion to match the frozen async persistence path.

## Runtime freeze
- Entire `payload/` tree is byte-identical to original v0.7ZG TIMINGFREEZE1A.
- No renderer changes.
- No native changes.
- No exposure changes.
- No queue/admission changes.
- No metadata/timing runtime changes.

## Host validation
- `patches/verify-m9cam-v0.7-r35.py` compiles with `python3 -m py_compile`.
- Updated verifier needle is present in `M9PrimaryTimingWriter.java`.
- Full payload SHA comparison against original v0.7ZG: PASS, byte-identical.
- ZIP integrity: PASS.

## Expected GitHub result
The formerly failing seam should now report:

`OK   PRIMARY1 timing uses Photon SAF storage helper`

All other v0.7ZG verification behavior is unchanged.
