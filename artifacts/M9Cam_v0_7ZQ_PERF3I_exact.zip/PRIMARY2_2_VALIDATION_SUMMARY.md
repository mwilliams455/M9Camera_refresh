# PRIMARY2.2 Validation Summary

**Package label:** v0.7T PRIMARY2.2 BRIDGE1/HSMFAST1  
**Base:** exact validated v0.7S PRIMARY2.1 FIX1  
**Build identity:** `1.03-m9modern7r38luma24fb1primary22`  
**Renderer schema:** `m9cam.renderer.r38.h25tg1.full12.android.v6.primary2p2`  
**Route:** `M9-PRIMARY2.2`

## Purpose

PRIMARY2.1 reduced RAW normalization to 661 ms but the latest full-resolution device capture still spent 2339 ms in `fullColorRenderElapsedMs` (~55% of the 4258 ms renderer). PRIMARY2.2 therefore changes only execution of the frozen full-colour mathematics.

No photographic parameter, saturation bank, tone curve, BT.601 coefficient, TG1 behavior, TC20 algorithm, exposure policy, RAW normalization formula, worker count, strip size, queue depth, or save policy is changed.

## Change 1 — BRIDGE1 precomposed M9 bridge

The PRIMARY2.1 hot loop performed this invariant chain for every pixel after HSM:

```text
ProPhoto RGB
  -> PP_TO_XYZ 3x3
  -> Bradford D50-to-scene 3x3
  -> M9 colour matrix 3x3
  -> / M9 white (three per-channel divides)
```

PRIMARY2.2 composes the frame-invariant chain once in `buildColorContext()`:

```text
ppToM9 = diag(1 / mwhite) * M9CM * adapt50ToScene * PP_TO_XYZ
```

The pixel loop then executes one 3x3 dot product only.

### Quantified parity evidence

The exact nine-frame regression set was evaluated at 1600x1200 using Java-like explicit 3x3 operation ordering for both the old chain and the precomposed chain.

```text
frames                       9
pixels                       17,280,000
14-bit channel values        51,840,000
pre-SAT3 14-bit channel diffs 0
pixel diffs                   0
maximum 14-bit difference     0
maximum floating abs delta    6.661338147750939e-16
CCT coverage                  ~3657 K to ~6130 K
TC20 gain coverage            ~1.239x to ~1.878x
```

Because the frozen SAT3/curve02/BT.601/TG1 chain receives identical quantized 14-bit values in this regression, downstream photographic output is identical for the tested set.

Evidence is stored in:

```text
reference/primary22_bridge_parity_evidence.json
```

## Change 2 — HSMFAST1 exact hot-loop simplification

The frozen H25 HSM implementation executed two floating `% 6.0` hue remainder operations per full-resolution pixel: once before HSV reconstruction and again at the start of HSV-to-RGB.

At 4096x3072 this is approximately:

```text
12,582,912 pixels
25,165,824 floating hue-remainder operations per photo
```

The frozen Cobalt calibration asset has hue deltas bounded to approximately:

```text
-25.21723 .. +10.633671 degrees
```

With H25 this can move the six-sector hue coordinate by only about:

```text
-0.1051 .. +0.0443 sectors
```

Therefore only one boundary crossing is possible and `% 6.0` is replaced by one exact branch wrap:

```text
if (hue < 0) hue += 6;
else if (hue >= 6) hue -= 6;
```

The second modulo in HSV-to-RGB is removed because the caller now guarantees hue in `[0,6)`.

Additional exact simplifications:

```text
s = gap / v
```

is used inside `gap > 1e-12`, where reachable non-negative RGB guarantees `v > 1e-12`; non-negative `floor()` calls become integer casts; adjacent HSM indices use `e00 + 3` / `e01 + 3`; and `(1-hf)` / `(1-sf)` are calculated once and reused.

A deterministic JVM host microcheck over 3,000,000 random RGB/HSM samples produced:

```text
bit-level output mismatches = 0
```

Host timing was directionally faster (roughly 8–23% for the isolated HSM function across warm runs), but device timing is the only acceptance metric.

## Frozen stage guards retained

The PRIMARY2 colour-loop source hash is unchanged:

```text
419a95a0fb147fb4bf0e06eaac4a95f2a1f04e2f6b6594c27f32a211d9b20c1a
```

This verifies the full-resolution pair loop still retains:

```text
4-worker bounded scheduling
24-row strips
cameraToM9 -> m9CurvePixel ordering
SAT3 branch accounting
exact horizontal 2-pixel BT.601 arithmetic
TG1 application
ordered Bitmap commits
```

PRIMARY2.1 normalization source parity also remains unchanged:

```text
7ec1c0039fa0a4e26812eaa20c14cc5532d21495d6fde89ac726ad9ad0b431ee
```

## Device acceptance target

PRIMARY2.1 reference:

```text
fullColorRenderElapsedMs = 2339
renderElapsedMs          = 4258
```

PRIMARY2.2 should be judged primarily on:

```text
fullColorRenderElapsedMs
renderElapsedMs
visual seam/race check
```

Interpretation:

```text
<= 2000 ms full colour  meaningful PASS
<= 1700 ms              strong Java hot-loop result
<= 1500 ms              excellent result; reassess whether JNI is still needed immediately
```

If BRIDGE1/HSMFAST1 does not materially reduce device time, the next investigation should profile/optimize the remaining HSM interpolation and SAT3/BT.601 packing, then move to scalar JNI only if Java has reached its practical ceiling.
