# PRIMARY2 Validation Summary

## Build

Package label: **v0.7R PRIMARY2**

Build identity:

```text
1.01-m9modern7r38luma24fb1primary2
```

Renderer schema:

```text
m9cam.renderer.r38.h25tg1.full12.android.v4.primary2
```

Timing route:

```text
M9-PRIMARY2
```

## Why PRIMARY2 exists

Two PRIMARY1-FIX1 device captures established that the fused full-resolution colour stage is the dominant renderer bottleneck:

```text
Capture 113252:
  renderElapsedMs          9653
  fullColorRenderElapsedMs 6841  (~70.9%)

Capture 113210:
  renderElapsedMs          7613
  fullColorRenderElapsedMs 5388  (~70.8%)

Observed full-colour average: 6114.5 ms
```

Ownership remained zero-copy (`ownershipTransferElapsedMs = 0`) and queue wait was zero in both samples. Therefore PRIMARY2 changes renderer scheduling only.

## PRIMARY2 implementation

The frozen 24-row strip geometry remains unchanged.

PRIMARY1 executed every strip's full colour math serially. PRIMARY2 now uses a bounded worker set:

```text
parallelColorWorkers = min(4, availableProcessors), floor 2
parallelColorMode    = bounded_strip_math_only
```

On the target Xiaomi 15 Ultra this is expected to resolve to 4 workers.

Important concurrency boundaries:

```text
OpenCV Mat.get strip extraction    SERIAL
H25/HSM -> M9 -> SAT3 -> curve02
  -> BT.601 horizontal pairs -> TG1   PARALLEL (pure Java strip math only)
Future join / counter reduction    SERIAL + deterministic
Bitmap.setPixels                    SERIAL + source-row ordered
```

The outer PRIMARY queue remains one worker with max two pending frames. PRIMARY2 does **not** permit two full M9 renders to execute concurrently.

## Photographic parity

No photographic constants were changed.

Frozen blocks were byte/text identical to v0.7Q PRIMARY1-FIX1:

```text
meter / TC20 / HSM / TG1 constants SHA-256:
f1ce8ad716dd40c1ba9eacaf78aac380c8a640b09b1d4b44d5bb95e57fcaecf1

SAT3 QE/QO matrix block SHA-256:
92469e71c971b287749c8fa7c0f3b949b5770ce3d8c9880de00e42226bc876e8

M9 camera-matrix block SHA-256:
aba972f5bb71b70fd6bf394d4305fbbf250760a93596ea4597203eaf83a3e85a
```

More importantly, PRIMARY2's extracted worker pixel/pair loop is textually identical to the validated PRIMARY1 loop after only the necessary parameter-name substitutions:

```text
meter.gain  -> gain
cal.curve02 -> curve02
```

Canonical frozen colour-loop SHA-256:

```text
419a95a0fb147fb4bf0e06eaac4a95f2a1f04e2f6b6594c27f32a211d9b20c1a
```

This means H25/HSM, M9 bridge, SAT3, curve02, horizontal two-pixel BT.601 arithmetic, TG1, rounding, clipping and odd-width fallback are not mathematically rewritten by PRIMARY2.

## Frozen state

No changes to:

```text
R3.8 H25 / S85 / V100
M9 camera-space bridge
TC20 algorithm or 1600-side meter
SAT3 M06/M07
curve02
exact horizontal BT.601 4:2:2
TG1
LUMA2.4-SPATIAL2
FB1 +0.75 EV cap
motion exposure policy
RAW normalization arithmetic
OpenCV EA demosaic
orientation
JPEG quality 95
PRIMARY zero-copy ImageFrame ownership
single outer render worker / max-two pending queue
JPEG-before-development-DNG ordering
Photon SAF timing-sidecar persistence
```

## Static/regression validation

Passed locally:

```text
Python patch/verifier syntax                         PASS
PRIMARY2 frozen PRIMARY1 colour-loop source parity  PASS
FULL12 streamed SAT3/curve02/BT601/TG1 regression   PASS
LUMA2.2 independent 8-frame regression               PASS
LUMA2.3 spatial orientation regression               PASS
LUMA2.3 frozen-decision regression                   PASS
LUMA2.4 exact-field regression                       PASS
LUMA2.4 landscape-proxy regression                   PASS
LUMA2.4 FB1 energy arithmetic regression             PASS
```

The package cannot replace the Android/GitHub compile as the final Java/Android validation; device build + capture is the decisive test.

## First device test

Take 2 full-resolution frames, preferably one ordinary scene and one higher-contrast/backlit scene.

Return the matching:

```text
*_M9_PRIMARY.json
*_M9.json
```

Primary fields to compare against PRIMARY1:

```text
renderer.parallelColorWorkers
renderer.parallelColorMode
renderer.fullColorRenderElapsedMs
renderer.renderElapsedMs
renderer.normalizeRawElapsedMs
renderer.meterTc20ElapsedMs
captureMetadataElapsedMs
queueWaitElapsedMs
```

Also verify:

```text
normal IMG_....jpg is produced
same native dimensions/orientation
no strip seams
no row corruption
no colour/tone drift
no crash/OOM
_M9_PRIMARY.json still persists
DNG still saves after JPEG
second shutter remains usable while renderer is active
```

## Performance interpretation

The PRIMARY1 full-colour baseline from the two measured samples is ~6.11 s.

A useful first-pass PRIMARY2 result would be:

```text
<= 3.5 s fullColorRenderElapsedMs   meaningful PASS
<= 2.5 s                            strong PASS
```

If parity is clean but Java parallelism remains materially slower than desired, the next step is a native/JNI implementation of this same frozen colour stage rather than widening photographic scope.
