# v0.7J LUMA2.1 diagnostic scorer — 21-frame regression

LUMA2.1 was evaluated against every complete instrumented field JSON currently available from the 2026-08-30 backlight investigation. The scorer uses **preview measurements only**; RAW clipping is not an input.

This build remains diagnostic-only:

```text
appliedExposureCorrectionEv = 0.0
feedbackEnabled = false
```

## Architectural change from v0.7I

v0.7I multiplied dark-body, absolute-bright and separation evidence geometrically. That made `brightPopulationScore == 0` a hard veto. Frame `172135` showed that coloured/translucent windows can produce strong relative backlight separation without enough Y>=192 occupancy to pass that veto.

LUMA2.1 instead uses:

```text
relative = cbrt(darkBodyScore * bodyHighlightSeparationScore)
absoluteBrightMultiplier = 0.62 + 0.38 * brightPopulationScore
structure = relative * absoluteBrightMultiplier
score = structure * energyStarvationScore
```

The existing dark, bright, separation, energy and EV ramps are otherwise retained.

## Regression result

| Frame | Class | Energy | dark<=64 | bright>=192 | q95-med | score | wouldApply | recommended EV |
|---|---|---:|---:|---:|---:|---:|:---:|---:|
| 161609 | cloudy control | 0.115 | 15.4% | 0.9% | 52 | 0.000 | NO | +0.000 |
| 161635 | cloudy control | 0.065 | 5.9% | 0.7% | 47 | 0.000 | NO | +0.000 |
| 161824 | cloudy control | 0.081 | 0.6% | 0.5% | 31 | 0.000 | NO | +0.000 |
| 171822 | severe backlight | 0.930 | 38.6% | 11.2% | 118 | 1.000 | YES | +0.750 |
| 172008 | high-energy control | 61.010 | 27.3% | 0.5% | 40 | 0.000 | NO | +0.000 |
| 172015 | high-energy control | 56.940 | 43.9% | 4.2% | 109 | 0.000 | NO | +0.000 |
| 172030 | high-energy/high-contrast control | 32.263 | 38.3% | 18.9% | 116 | 0.000 | NO | +0.000 |
| 172042 | severe backlight | 1.080 | 52.0% | 11.0% | 149 | 0.992 | YES | +0.750 |
| 172135 | coloured-window edge case | 0.198 | 36.9% | 1.2% | 93 | 0.559 | YES | +0.283 |
| 172240 | high-energy control | 24.920 | 39.8% | 2.2% | 97 | 0.000 | NO | +0.000 |
| 172303 | flower/window guard | 0.610 | 19.7% | 2.9% | 67 | 0.000 | NO | +0.000 |
| 154013 | severe backlight | 0.363 | 78.6% | 9.5% | 168 | 0.993 | YES | +0.750 |
| 154305 | severe backlight | 0.940 | 46.2% | 9.7% | 121 | 0.997 | YES | +0.750 |
| 154325 | high-energy guard | 3.870 | 49.8% | 9.4% | 138 | 0.000 | NO | +0.000 |
| 154457 | severe backlight | 0.433 | 65.2% | 19.0% | 179 | 1.000 | YES | +0.750 |
| 154522 | high-energy backlit guard | 4.140 | 56.2% | 15.9% | 175 | 0.000 | NO | +0.000 |
| 154550 | healthy/high-energy guard | 6.980 | 38.0% | 20.0% | 117 | 0.000 | NO | +0.000 |
| 154649 | severe backlight | 0.500 | 29.1% | 15.3% | 94 | 0.793 | YES | +0.723 |
| 154725 | healthy/high-energy guard | 21.510 | 42.6% | 7.0% | 122 | 0.000 | NO | +0.000 |
| 154734 | normal control | 21.320 | 19.0% | 0.0% | 42 | 0.000 | NO | +0.000 |
| 154749 | mild/guard | 2.850 | 21.5% | 4.9% | 52 | 0.000 | NO | +0.000 |

## Key outcomes

- All previously established severe backlight positives remain positive.
- `154649` retains approximately the v0.7I response (~+0.72 EV).
- `171822` and `172042` remain at the +0.75 EV diagnostic cap.
- `172135` changes from 0 EV to **+0.283 EV**, specifically because absolute bright occupancy no longer acts as a veto.
- `172303` remains 0 EV because its dark-body score stays below the structural activation range.
- All three cloudy controls (`161609`, `161635`, `161824`) remain exactly 0 EV despite extremely low preview exposure energy.
- High-energy backlit/high-contrast controls remain 0 EV because the existing energy-starvation gate still dominates.

## Promotion status

This 21-frame regression is sufficient to build the revised diagnostic field candidate, **not** to enable exposure feedback. v0.7J should be challenged with new independent scenes before the scorer is allowed to modify Photon target exposure energy.
