# PERF3H CVDIRECT1A Validation Summary

**Candidate:** `v0.7ZP / PRIMARY2.5 / PERF3H CVDIRECT1A`  
**Base:** device-promoted `v0.7ZO / PERF3G ORIENTFUSE8A`  
**Status:** HOST/STATIC VALIDATED TEST CANDIDATE — NOT YET DEVICE-PROMOTED

## Purpose

Remove duplicate input-side memory copies around OpenCV without changing any photographic arithmetic or Android Bitmap/JPEG behavior.

Latest PERF3G rapid medians still show approximately:

```text
full-color OpenCV Mat -> Java short[]      13.15 ms
full-color JNI short[] -> native scratch    5.11 ms
TC20 meter Mat -> Java short[]              10.00 ms
TC20 JNI camera input copy                   0.81 ms
```

These are pure input transport costs. PERF3H targets them before attempting the higher-risk Android native Bitmap destination path.

## Frozen quality / architecture gates

Unchanged:

- 12 MP output (`4096x3072` pre-orientation; `3072x4096` at 90°);
- `jpegQuality = 95`;
- Android `Bitmap.compress(JPEG, quality=95)` encoder;
- JPEGBUF64K1A 64 KiB output buffering;
- EXIFASYNC1A finalizer and JPEG-before-DNG publication ordering;
- DNGASYNC1A ownership/preservation architecture;
- QUEUE1B bounded admission behavior;
- ORIENTFUSE8A;
- COLOR8A worker count = 8;
- TC20LUMA8A;
- R3.8 H25/TG1;
- Cobalt main-camera calibration;
- M9 bridge;
- SAT3 M06/M07;
- curve02;
- exact firmware-style BT.601 horizontal 4:2:2;
- exposure policy.

Still forbidden:

- JPEG quality reduction;
- encoder replacement;
- resolution reduction;
- fast-math;
- NEON approximation;
- photographic-kernel changes;
- queue widening merely to hide latency.

## Exact execution change

### PERF3G TC20 input

```text
OpenCV meter Mat
-> Mat.get(short[])
-> Java short[]
-> JNI GetShortArrayRegion
-> native scratch
-> exact TC20 scalar routine
```

### PERF3H TC20 input

Normal path only when all layout guards pass:

```text
OpenCV meter Mat
-> validated packed/continuous CV_16U x3 storage
-> Mat.dataAddr()
-> synchronous JNI direct read
-> exact same TC20 scalar routine
```

Fallback on any unexpected Mat layout:

```text
original PERF3G copied-input path
```

### PERF3G full-color input

For each 384-row block:

```text
cam16 Mat
-> Mat.get(short[])
-> Java camBlock
-> JNI GetShortArrayRegion
-> native camScratch
-> exact 8-worker scalar COLOR + ORIENTFUSE8A
```

### PERF3H full-color input

When the full demosaic Mat is explicitly verified packed/continuous:

```text
cam16 Mat
-> validated dataAddr + block row offset
-> synchronous JNI direct read
-> exact same 8-worker scalar COLOR + ORIENTFUSE8A
```

Unexpected Mat layout uses the original copied path.

PERF3H deliberately does **not** write Android Bitmap memory directly. The retained output path is still:

```text
native orientedScratch
-> JNI SetIntArrayRegion
-> Java int[] argbBlock
-> Bitmap.setPixels
```

That isolates this experiment to camera-input transport only.

## Mat safety gate

Direct input is allowed only when Java confirms:

```text
isContinuous() == true
channels() == 3
elemSize1() == 2
step1() == width * 3
dataAddr() != 0
```

The resized TC20 Mat applies the equivalent `meterW * 3` stride check.

If any check fails, PERF3H does not guess about memory layout. It falls back to the exact promoted Java short-array path.

The Mat remains alive until the synchronous JNI call and all internal native worker threads have joined.

## Frozen native photographic-kernel hashes

All quality-critical functions remain unchanged:

```text
applyHsm
7f4e1e8224d976b65be68ae21fe5fcd3d5ef43d461507ea33f87c2007fffbe5a

cameraToSrgbLuma
d2247d137a35f6ef0729df2977c494f30d54da438ed0b98197a529bdb7bbe382

cameraToM9
a3d216769a59128825c44b5b69f7f9d9219dddb76c43e00bb462293afedf2bc9

m9CurvePixel
0c88877b5d50cf409bae84fe95e6e172184f2e7f0c39352b763fd5dafa7a9d5f

renderStripScalar
c157a252e4d29657ff000f3241c21a3c9cb89dfa57769b0579e6f22ac928faa0

orientCompletedStrip
534221e756b6d5af9e54312dfad441e25120d2941e288473d7b5aeda28faa51d
```

## Host validation

### Source guard

```text
PERF3H CVDIRECT1A source guard PASS
```

The guard confirms:

- all six frozen hashes above;
- direct TC20 and full-color JNI seams exist;
- direct path is gated by continuity/channel/element-size/stride/address checks;
- promoted copied-input fallbacks remain present;
- ORIENTFUSE8A remains active;
- JPEG quality remains 95.

### Actual scalar COLOR kernel input parity

The host harness feeds the **actual frozen `renderStripScalar()`** with two representations of the same CV_16U bit patterns:

1. the historical copied `jshort` block;
2. a direct pointer view over packed unsigned-16 storage.

It includes values above `32767` and explicit `0/32767/32768/65535` edge patterns so signed Java `short` representation cannot hide a bit-interpretation mismatch.

Both `-O2` and production-style `-O3 -ffp-contract=off -fno-fast-math` runs passed:

```text
PERF3H CVDIRECT1A actual scalar-kernel input parity PASS 15316 block cases
```

### TC20 direct-input parity

The actual frozen `meterTc20WeightedSelectScalar()` was run from copied and direct packed inputs with identical weights.

Both optimization-level runs passed exactly:

```text
PERF3H CVDIRECT1A TC20 direct-input parity PASS 12 cases
```

### Compile/static smoke

```text
m9color_jni.cpp host C++17 syntax PASS
M9NativeColorCore javac PASS
patch/verifier py_compile PASS
```

A complete Android/Gradle APK build is not possible from the overlay alone; device build remains the next gate.

## Diagnostics

Expected new fields:

```text
performanceForensics = PERF3H_CVDIRECT1A_ORIENTFUSE8A_EXIFASYNC1A_JPEGBUF64K1A_TC20LUMA8A_COLOR8A

meterInputMode = opencv_mat_dataaddr_direct1a
meterCvDirectEligible = true
meterCvDirectFallback = false

nativeColorInputMode = opencv_mat_dataaddr_direct1a
nativeColorCvDirectEligible = true
nativeColorCvDirectBlocks = 8
nativeColorCvFallbackBlocks = 0
nativeColorCvStepShorts = 12288    # expected for 4096 x 3 packed channels
```

If any layout check unexpectedly fails, diagnostics should instead report the Java-short-array fallback while output remains correct.

## Expected device effect

PERF3G five-frame rapid medians supply the approximate removable transport budget:

```text
nativeColorOpenCvTransferElapsedMsSum   13.15 ms
nativeColorInputCopyElapsedMsSum         5.11 ms
meterTransferElapsedMs                  10.00 ms
tc20NativeInputCopyElapsedMs             0.81 ms
```

Not every millisecond will convert directly to worker-wall savings, but a healthy PERF3H frame should make the first three transport fields collapse toward near-zero/weight-only overhead.

A useful end-to-end improvement would be roughly **15–30 ms** while keeping output and metadata exact.

## Device acceptance gate

Test one settled standalone frame and 4–5 rapid frames after cooling.

Require on the expected direct path:

```text
performanceForensics contains PERF3H_CVDIRECT1A
meterInputMode = opencv_mat_dataaddr_direct1a
meterCvDirectEligible = true
meterCvDirectFallback = false
nativeColorInputMode = opencv_mat_dataaddr_direct1a
nativeColorCvDirectEligible = true
nativeColorCvDirectBlocks = 8
nativeColorCvFallbackBlocks = 0
jpegQuality = 95
jpegExifAsyncAccepted = true
jpegExifSyncFallback = false
jpegExifFinalizeSuccess = true
jpegPublicationAfterExif = true
jpegSaved = true
dngSaved = true
rawFrameCloseOwner = M9PrimaryDngIO
```

Compare especially:

```text
meterTransferElapsedMs
tc20NativeInputCopyElapsedMs
nativeColorOpenCvTransferElapsedMsSum
nativeColorInputCopyElapsedMsSum
nativeColorWorkerWallElapsedMsSum
fullColorRenderElapsedMs
renderCoreElapsedMs
workerElapsedMs
queueWaitElapsedMs
admissionRejectCountSnapshot
```

Promotion requires output correctness first. If the direct Mat gate fails on-device, do not remove the fallback; inspect the reported stride/type/layout instead.

## FIX1 — inherited verifier compatibility correction

The first distributed PERF3H package contained one stale verifier invariant:

```text
COLORNATIVE2A serializes OpenCV extraction before JNI
```

That invariant is correct for pre-PERF3H branches, but contradicts CVDIRECT1A by requiring the copied `cam16.get(...)` path to occur before the first native render call. In PERF3H the normal path is intentionally the already-validated guarded `renderBlockParallelDirect(...)` call, while `cam16.get(...) -> renderBlockParallel(...)` remains only as the preservation fallback.

FIX1 changes **only** `patches/verify-m9cam-v0.7-r35.py`:

- pre-PERF3H builds still must satisfy the historical extraction-before-JNI ordering check;
- PERF3H must contain the guarded direct JNI seam, the copied fallback seam, the CVDIRECT1A marker, direct-eligibility telemetry, and fallback telemetry;
- no renderer, JNI, C++, exposure, JPEG, DNG, queue, or photographic source is changed.

`apply-m9cam-v0.7-r35-parity.py` and all application/native payload files are byte-identical to the originally distributed PERF3H candidate.

FIX1 verifier Python compilation: PASS.
