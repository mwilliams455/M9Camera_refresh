# PERF3C TC20LUMA8A + COLOR8A validation summary

## Device evidence driving this branch

PERF3B COLOR8A was evaluated from six device PRIMARY sidecars (one standalone + five rapid captures). The five-shot burst median versus the prior PERF3A 4-worker baseline was:

| Metric | PERF3A 4-worker | PERF3B COLOR8A | Change |
|---|---:|---:|---:|
| native colour worker wall | 309.1 ms | 261.8 ms | -15.3% |
| full colour stage | 383 ms | 338 ms | -11.7% |
| TC20 total | 165 ms | 164 ms | essentially unchanged |
| render core | 621 ms | 581 ms | -6.4% |
| JPEG encode/write | 192 ms | 149 ms | -22.4% |
| render-worker occupancy | 860 ms | 783 ms | -9.0% |
| queue wait | 1402 ms | 719 ms | capture-cadence sensitive; directionally improved |

All six COLOR8A sidecars reported eight native colour workers, successful JPEG+DNG output, async DNG acceptance and no synchronous DNG fallback.

Conclusion: COLOR8A is retained. It reduced scalar colour compute without moving cost into JPEG or DNG I/O.

## PERF3C change

The next remaining safe compute target is TC20's H25/HSM -> sRGB-linear luma population, which remained roughly 75-80 ms on device.

PERF3C changes only that luma-population traversal:

1. Allocate/resize the existing caller-thread `thread_local` luma vector exactly as before.
2. Freeze an ordinary `double*` to that storage before spawning child threads.
3. Compute `cameraToSrgbLuma()` for disjoint contiguous pixel ranges using up to eight native workers.
4. Join all workers.
5. Rebuild the valid `order` vector serially in the original ascending pixel-index order.
6. Run the existing TC20NATIVE1B total-weight, weighted-median partition selection and P98 rank selection unchanged.

The ordered index rebuild is deliberate: it ensures the selection stage sees the same initial index ordering as the promoted scalar implementation.

No exposure, H25/HSM arithmetic, TC20 thresholds, gain/headroom decision, M9 bridge, SAT3, curve02, BT.601/TG1, JPEG, DNG, queue or ownership behavior is changed.

## Thread-local safety gate

The first host draft correctly failed: child threads referenced the caller's `thread_local y` vector by name, resolving to empty child-thread TLS storage. This reproduced the same class of error previously solved in COLORNATIVE2A-FIX1.

That draft was discarded.

The corrected implementation freezes `double* const yBase = y.data()` on the JNI caller thread before spawning and writes only through that stable pointer. The vector is not resized until all workers have joined.

## Host validation

### Python patch/verifier syntax

PASS: both patch scripts compile with Python 3.

### Native build

PASS: `m9color_jni.cpp` builds as a host JNI shared object with:

`-std=c++17 -O3 -ffp-contract=off -fno-fast-math -pthread`

### Existing TC20 Java-vs-JNI parity

PASS using the original deterministic TC20NATIVE1B parity harness:

- Java weighted median: `0.46205609372066964`
- Native weighted median: `0.46205609372066964`
- Java P98: `0.82639677488795830`
- Native P98: `0.82639677488795830`
- valid population: `49082` on both paths

### PERF3C stress/parity harness

PASS: 50 consecutive JNI calls using a 13-value timing result buffer preserved the same Java-vs-native median, P98 and valid count, reported eight luma workers, and populated the new luma-compute/order-build timing probes.

## New diagnostics

- `performanceForensics = PERF3C_TC20LUMA8A_COLOR8A`
- `tc20MeterMode = native_parallel_luma8_weightedselect_parity1b`
- `tc20NativeLumaComputeElapsedMs`
- `tc20NativeOrderBuildElapsedMs`
- `tc20NativeLumaWorkersUsed`

Existing PERF3A/PERF3B timing fields remain present for direct comparison.

## Device acceptance gate

This branch is experimental until device validation.

Expected useful result:

- TC20 luma population falls materially from ~76 ms;
- `meterTc20ElapsedMs` falls without changing gain/P98/TC20 decisions;
- COLOR8A remains in the same performance range;
- JPEG and DNG both save normally;
- no crash/OOM and no DNG fallback regression.

If TC20 luma does not scale materially on device, revert this branch and investigate the remaining weighted-median/P98 selection cost instead.

### Retained COLOR8A row-partition parity

PASS: the existing COLORNATIVE2A row-partition scalar parity harness still passes against the unchanged production colour kernel.
