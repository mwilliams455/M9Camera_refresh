# PRIMARY2.3 JNI1 FIX7 validation summary

## Failure resolved
The FIX6 GitHub build reached `:app:mergeDebugNativeLibs` and failed because Gradle saw two copies of `lib/arm64-v8a/libm9color.so`:

- `app/build/intermediates/merged_jni_libs/.../libm9color.so` (FIX6 jniLibs copy)
- `app/build/intermediates/cxx/.../obj/arm64-v8a/libm9color.so` (CMake copy)

That proves the repository still had an active CMake `m9color` target while FIX6 generated a second library manually.

Combined with the earlier device logcat (`libncnnMl.so not found`) and FIX5 finding zero `ncnnMl` CMake targets, the persistent root cause is the original JNI1 CMake replacement: PhotonCamera's native CMake baseline had been replaced by an M9-only project and that repository state carried forward.

## FIX7 repair
FIX7 no longer uses the direct-NDK/jniLibs workaround.

At patch time it:

1. Inspects `app/src/main/cpp/CMakeLists.txt` for Photon native landmarks (`project(dngCreator)`, `ncnnMl`, DNG creator, allocator, FLAC recorder, camera2native).
2. If the baseline is contaminated or an older `m9color` target exists, it first searches local Git history for the last clean Photon CMake.
3. If a shallow checkout has no clean historical file, it falls back to canonical `eszdman/PhotonCamera@dev` CMake and validates all native landmarks before writing it.
4. It verifies the checkout still contains `dngCreator.cpp`, `allocator.cpp`, `flacRecorder.cpp`, and `native-engine.cpp`.
5. It removes any stale FIX6 `app/src/main/jniLibs/{ABI}/libm9color.so` files.
6. It appends exactly one CMake `m9color` shared-library target with `-O3 -ffp-contract=off -fno-fast-math` and 16 KiB link alignment.
7. It does not add or replace Gradle `externalNativeBuild` wiring.

## Recovery regression
A temporary Git repository was constructed with:

- commit 1: clean Photon-like CMake containing `ncnnMl`, dngCreator, allocator, flacRecorder and camera2native;
- commit 2: contaminated M9-only CMake containing only `m9color`;
- a stale FIX6 `jniLibs/arm64-v8a/libm9color.so`.

FIX7 result:

- clean native baseline recovered from Git history: PASS
- stale jniLibs copy removed: PASS
- exactly one `ncnnMl` target after repair: PASS
- exactly one `m9color` target after repair: PASS
- repeated FIX7 application remains idempotent: PASS

## Renderer parity
`m9color_jni.cpp` SHA-256 is unchanged from FIX6:

`e600e4b3895a4e7b8cce8d95a0e18303c9d4659a665692105ece11a910505d4e`

The actual scalar C++ parity harness was recompiled with:

`-O3 -ffp-contract=off -fno-fast-math`

Java oracle vs actual C++ output: exact match.

- case0 `d8a41181af097d65`
- case1 `4fa72399bad9d8bb`
- case2 `4186500ffb6b1f36`
- case3 `b9b94cc14c4f68ca`
- aggregate `7e21b6ae4a9557ae`
- 99,716 pixel-cases total

PRIMARY2.3 scheduling guard (4 workers / 24 rows, serialized OpenCV extraction and ordered Bitmap commit): PASS.

## Expected GitHub patch output
On the contaminated repository the patch should print a line similar to:

`FIX7 restored Photon native CMake baseline from git:<commit>`

or, for a shallow checkout:

`FIX7 restored Photon native CMake baseline from upstream:eszdman/PhotonCamera@dev`

Then:

`FIX7 appended single m9color target to restored Photon CMake project`

There should be no `FIX6 built app/src/main/jniLibs/...` messages.

## Expected build behavior
Gradle should continue to run `configureCMakeDebug` / `buildCMakeDebug` for both ABIs. The restored Photon project should generate `libncnnMl.so` and the original native libraries, while the same CMake project generates one `libm9color.so`. `mergeDebugNativeLibs` should no longer see a duplicate m9color input.
