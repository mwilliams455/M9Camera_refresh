# PRIMARY2.1 FIX1 Validation Summary

## Scope

Compile-only correction to the first v0.7S PRIMARY2.1 package.

The Android build failed because the RAW-normalization worker lambda captured `norm16`, while the method later assigns `norm16 = null` after `rawMat.put(...)`. Java therefore does not consider that local effectively final.

FIX1 adds final worker aliases before executor submission:

```java
final short[] normalizeOut = norm16;
final int normalizeWidth = width;
final float[] normalizeBlack = black;
```

and passes those aliases to `normalizeRange(...)`.

## Unchanged

- normalization per-pixel arithmetic
- CFA plane selection
- four-worker disjoint row partitioning
- private histogram/clipping counters and serial reduction
- post-copy `norm16 = null` memory release
- OpenCV EA demosaic
- TC20 and 1600-side meter
- PRIMARY2 four-worker full-colour renderer
- H25/S85/V100, M9 bridge, SAT3, curve02, exact BT.601, TG1
- LUMA2.4-SPATIAL2-FB1 and motion policy
- PRIMARY zero-copy ownership, queue depth and save ordering

## Validation

```text
PRIMARY2.1 normalization arithmetic parity SHA-256
7ec1c0039fa0a4e26812eaa20c14cc5532d21495d6fde89ac726ad9ad0b431ee

PRIMARY2 colour-loop parity SHA-256
419a95a0fb147fb4bf0e06eaac4a95f2a1f04e2f6b6594c27f32a211d9b20c1a

targeted javac lambda-capture smoke with later norm16=null  PASS
FULL12 streamed stage regression                              PASS
LUMA2.2 regression                                             PASS
LUMA2.3 orientation/frozen decision regressions                PASS
LUMA2.4 exact-field/landscape regressions                      PASS
LUMA2.4 FB1 energy regression                                  PASS
```

Build identity intentionally remains `1.02-m9modern7r38luma24fb1primary21` because the first v0.7S package never produced an installable APK.
