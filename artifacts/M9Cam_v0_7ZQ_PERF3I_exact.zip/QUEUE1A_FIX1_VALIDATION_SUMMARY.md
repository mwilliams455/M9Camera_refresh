# QUEUE1A FIX1 validation summary

## Failure

The first v0.7ZE QUEUE1A package correctly installed the QUEUE1A payload and then failed in the patch script's late self-check with:

```text
v0.7D self-check failed: 'm9cam.primarytiming.v1' missing from app/src/main/java/com/particlesdevs/photoncamera/m9/render/M9PrimaryTimingWriter.java
```

## Root cause

QUEUE1A intentionally bumped the primary timing schema from:

```text
m9cam.primarytiming.v1
```

to:

```text
m9cam.primarytiming.v2.queue1a
```

The patch script already had the correct QUEUE1A assertion earlier in its self-check block, but one inherited legacy `v1` assertion remained later in the same block. Therefore a correctly patched QUEUE1A tree necessarily failed that stale assertion.

## FIX1

Removed only the obsolete late `m9cam.primarytiming.v1` self-check. The existing required assertion for `m9cam.primarytiming.v2.queue1a` remains.

No app source or photographic/render behavior changed. In particular, FIX1 preserves exactly:

- QUEUE1A nonblocking queue-full rejection;
- `MAX_PENDING = 2`;
- boolean enqueue acceptance contract;
- QUEUE1A timing telemetry;
- COLORNATIVE2A FIX1;
- TC20NATIVE1B;
- ORIENT1A;
- NORMNATIVE1A;
- METAFREEZE1A;
- H25/HSM, SAT3, curve02, BT.601/TG1;
- LUMA2.4-SPATIAL2-FB1 exposure behavior;
- APK `versionName` 1.20 identity;
- frozen renderer schema.

## Host/static validation

- patch script `py_compile`: PASS
- verifier `py_compile`: PASS
- QUEUE1A nonblocking guard: PASS
- stale `m9cam.primarytiming.v1` self-check in patch script: ABSENT
- required `m9cam.primarytiming.v2.queue1a` self-check: PRESENT
- `getQueue().put(job)` in queue payload: ABSENT
- QUEUE1A payload Java files unchanged from the first QUEUE1A package: YES

## Device/build gate

Re-run the normal GitHub workflow. It should now pass the self-check stage that previously aborted immediately after the COLORNATIVE2A FIX1 overlay was applied. If the build reaches a later failure, capture that new output; it will be a separate issue rather than this timing-schema mismatch.
