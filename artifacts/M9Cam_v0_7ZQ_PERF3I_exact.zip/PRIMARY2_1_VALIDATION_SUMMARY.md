# PRIMARY2.1 Validation Summary

## Build

Package label: **v0.7S PRIMARY2.1 FIX1**

Build identity:

```text
1.02-m9modern7r38luma24fb1primary21
```

Renderer schema:

```text
m9cam.renderer.r38.h25tg1.full12.android.v5.primary2p1
```

Timing route:

```text
M9-PRIMARY2.1
```

## Why PRIMARY2.1 exists

The first PRIMARY2 device capture validated four-worker bounded colour parallelism:

```text
renderElapsedMs          5946
fullColorRenderElapsedMs 2617
normalizeRawElapsedMs    1489
meterTc20ElapsedMs       1195
```

Compared with PRIMARY1's measured full-colour average (~6114.5 ms), PRIMARY2 reduced the colour stage to 2617 ms (~2.34x faster). RAW normalization then became the largest low-risk independent stage at ~1.49 s.

PRIMARY2.1 therefore changes only RAW normalization scheduling. TC20 remains serial/frozen.

## PRIMARY2.1 implementation

The PRIMARY2 colour path is retained unchanged. RAW normalization is divided into at most four contiguous row ranges:

```text
parallelNormalizeWorkers = min(4, availableProcessors), floor 2
parallelNormalizeMode    = disjoint_row_ranges_histogram_reduce
```

Each worker:

```text
owns an independent ShortBuffer duplicate
reads one non-overlapping source-row interval
writes the same interval of shared norm16[]
maintains private 4-plane raw histograms
maintains a private clipped-pixel count
```

After all workers join, histogram bins and clipped counts are reduced serially before the unchanged `rawTail(...)` call.

Concurrency boundaries:

```text
RAW normalization arithmetic + local histogram     PARALLEL
histogram/clipped reduction                         SERIAL / deterministic
OpenCV EA demosaic                                  UNCHANGED
1600-side INTER_AREA + TC20                         UNCHANGED / serial
PRIMARY2 H25/HSM -> M9 -> SAT3 -> curve02
  -> BT.601 horizontal pairs -> TG1                 UNCHANGED / 4-worker bounded
Bitmap writes                                       UNCHANGED / serial
```

## Arithmetic parity

PRIMARY2.1's extracted normalization pixel formula is textually identical to PRIMARY2 after only renaming the worker-local counters:

```text
localClipped -> clipped
localCounts  -> rawCounts
```

Canonical normalization arithmetic SHA-256:

```text
7ec1c0039fa0a4e26812eaa20c14cc5532d21495d6fde89ac726ad9ad0b431ee
```

The previously validated PRIMARY2 colour-loop parity guard also still passes unchanged:

```text
419a95a0fb147fb4bf0e06eaac4a95f2a1f04e2f6b6594c27f32a211d9b20c1a
```

Therefore neither normalization pixel math nor finished-colour pixel/pair math is rewritten.

## Frozen photographic state

No changes to:

```text
R3.8 H25 / S85 / V100
M9 camera-space bridge
TC20 algorithm or 1600-side meter
SAT3 M06/M07
curve02
exact horizontal BT.601 4:2:2
TG1
LUMA2.4-SPATIAL2
FB1 +0.75 EV cap
motion exposure policy
OpenCV EA demosaic
orientation
JPEG quality 95
PRIMARY zero-copy ImageFrame ownership
single outer render worker / max-two pending queue
JPEG-before-development-DNG ordering
Photon SAF timing-sidecar persistence
PRIMARY2 full-colour scheduling and arithmetic
```

`M9BacklightDiagnostic.java` differs from v0.7R only in build/schema identity. `M9PrimaryRenderQueue.java` and `M9PrimaryTimingWriter.java` differ only in PRIMARY2.1 labels/routes. `M9SubjectMotionAnalyzer.java`, `M9R35Calibration.java`, and the calibration binary are unchanged.

## Static/regression validation

Passed locally:

```text
Python patch/verifier/reference syntax                     PASS
targeted javac lambda-capture smoke with post-join norm16=null PASS
PRIMARY2.1 PRIMARY2 normalization source parity           PASS
PRIMARY2 PRIMARY1 colour-loop source parity               PASS
FULL12 streamed SAT3/curve02/BT601/TG1 regression         PASS
LUMA2.2 independent 8-frame regression                     PASS
LUMA2.3 spatial orientation regression                     PASS
LUMA2.3 frozen-decision regression                         PASS
LUMA2.4 exact-field regression                             PASS
LUMA2.4 landscape-proxy regression                         PASS
LUMA2.4 FB1 energy arithmetic regression                   PASS
```

The GitHub Android build remains the decisive Java/Android compile validation.

## First device test

One full-resolution capture is enough for the first timing result. Return:

```text
*_M9_PRIMARY.json
*_M9.json
```

Verify:

```text
route = M9-PRIMARY2.1
renderer.parallelNormalizeWorkers = 4 (expected on target)
renderer.parallelNormalizeMode = disjoint_row_ranges_histogram_reduce
renderer.parallelColorWorkers = 4
normal IMG_....jpg produced
same native dimensions/orientation
no colour/tone change
no row/strip corruption
DNG and timing JSON persist
```

Primary performance field:

```text
normalizeRawElapsedMs
```

v0.7R device baseline:

```text
1489 ms
```

Interpretation for the first sample:

```text
<= 1000 ms    useful PASS
<= 750 ms     strong PASS
<= 600 ms     excellent result
```

Also record `renderElapsedMs` and `meterTc20ElapsedMs`. If normalization falls substantially while TC20 remains near ~1.2 s, TC20 becomes the next measured target rather than further widening the colour work.


## FIX1 Java compile correction

The first v0.7S source package failed the real Android javac step at the normalization lambda.
The original local parse-oriented check was insufficient to catch Java effectively-final capture semantics.

Root cause:

```text
norm16 is captured by the worker lambda
...
norm16 = null after rawMat.put(...)
```

Because of that later assignment, `norm16` is not effectively final. FIX1 creates explicit final aliases before worker submission:

```text
final short[] normalizeOut = norm16;
final int normalizeWidth = width;
final float[] normalizeBlack = black;
```

and the lambda calls:

```text
normalizeRange(workerShorts, normalizeOut, normalizeWidth, y0, y1, normalizeBlack, wl)
```

The existing `norm16 = null` lifetime/memory-release behaviour is retained after the joined workers feed OpenCV.
No normalization formula, CFA selection, histogram arithmetic, worker count, row boundaries or photographic stage changed.

FIX1 validation:

```text
PRIMARY2.1 frozen PRIMARY2 normalization arithmetic parity PASS
PRIMARY2 frozen PRIMARY1 colour-loop source parity PASS
targeted javac lambda-capture smoke with later norm16=null PASS
FULL12 streamed colour-stage regression PASS
LUMA2.2 / LUMA2.3 / LUMA2.4 / FB1 regressions PASS
```

The GitHub Android build remains the final compile validation.
