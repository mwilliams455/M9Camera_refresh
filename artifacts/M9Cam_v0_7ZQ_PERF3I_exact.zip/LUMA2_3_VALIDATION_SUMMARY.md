# LUMA2.3-SPATIAL1 validation plan

## Reason for this build

K/LUMA2.2 correctly handled the first center-body false positive and catastrophic
preview-collapse miss, but independent captures exposed a second outdoor family
that global/center histograms cannot safely separate.

| Frame | Visual class | K recommendation | Result |
|---|---|---:|---|
| 191728 | genuine dark high-contrast positive | +0.75 EV | PASS |
| 191721 | usable cloudy landscape negative | +0.75 EV | FALSE POSITIVE |

Their global diagnostics are too similar for another scalar threshold to be
well-founded.

## v0.7L change

No scorer changes. No exposure feedback. Add only orientation-aware spatial luma
instrumentation from the existing 96x72 Y plane.

New JSON path:

`subjectMotion.previewLuma.spatial3x3`

The spatial grid is rotated into displayed-image coordinates using
`cameraRotationDegrees`, then split into 3x3 tiles plus horizontal and vertical
thirds. Each region contains mean/median/q75/q90/q95, dark<=48, dark<=64,
bright>=192 and bright>=224.

## Frozen decision behavior

LUMA2.2 remains the active counterfactual scorer. Existing K decisions are
expected to remain unchanged, including the known 191721 false positive. That is
intentional: v0.7L is a measurement build, not a retune.

## Promotion gate

Do not define a spatial guard until new independent positive/negative captures
show a repeatable spatial distinction. Candidate features to inspect include:

- display top/middle/bottom median and bright occupancy
- tile-wise bright concentration
- tile-wise dark-body concentration
- whether usable landscape scenes preserve mid/foreground luminance in regions
  that genuine failed-backlight scenes do not

Any future spatial rule must preserve the already-clean indoor/cloudy/backlight
regression and remain diagnostic-only for one field cycle before live feedback.
