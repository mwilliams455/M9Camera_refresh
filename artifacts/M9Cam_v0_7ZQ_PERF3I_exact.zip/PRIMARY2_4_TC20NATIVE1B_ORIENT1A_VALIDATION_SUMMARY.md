# PRIMARY2.4 TC20NATIVE1B ORIENT1A validation summary

## Purpose

Eliminate the fixed ~188-190 ms Android full-frame orientation stage without changing the accepted photographic pipeline.

The incoming v0.7Z TC20NATIVE1B device checkpoint is promoted for TC20. ORIENT1A changes only final pixel placement.

## Frozen mathematics

Unchanged:

- RAW normalization
- OpenCV EA demosaic
- TC20NATIVE1B 1600-side weighted-selection meter
- H25/HSM
- M9 bridge
- SAT3 M06/M07
- curve02
- exact firmware BT.601 horizontal 4:2:2
- TG1
- exposure/LUMA2.4/SPATIAL2/FB1
- JPEG quality 95
- development DNG behavior

## ORIENT1A architecture

Previous:

```text
native source-order colour strips
    -> unrotated 4096x3072 Bitmap
    -> Android Matrix 90-degree full-frame copy
    -> 3072x4096 final Bitmap
```

ORIENT1A:

```text
native source-order colour strips
    -> exact source-horizontal BT.601 pairs completed
    -> strip-local ARGB destination-layout remap
    -> direct commit into final 3072x4096 Bitmap
```

The orientation remap occurs only after both pixels in every firmware 4:2:2 source-horizontal pair have been reconstructed. No display-space chroma pairing is introduced.

## Mapping formulas

For source strip local coordinates `(x, y)` with `rows = strip height`:

- 0° local index: `y * width + x`
- 90° local destination index: `x * rows + (rows - 1 - y)`
- 180° local destination index: `(rows - 1 - y) * width + (width - 1 - x)`
- 270° local destination index: `(width - 1 - x) * rows + y`

Java commits those local rectangles at the correct global destination offset.

## Host parity

`reference/orient1a_strip_destination_parity.py` assembled whole frames from independently oriented strips and compared against a whole-frame reference rotation.

Test geometries included:

```text
7x5 strip=2
8x6 strip=4
4x9 strip=3
16x3072 strip=24
```

All 0/90/180/270 cases passed exactly.

```text
ORIENT1A strip destination mapping exact parity PASS
```

The actual `m9color_jni.cpp` also passed host C++17 syntax compilation using the production scalar flags.

## Device gate

Incoming TC20NATIVE1B orientation reference:

```text
211836 orientationElapsedMs 188
211909 orientationElapsedMs 190
```

ORIENT1A must report:

```text
orientationElapsedMs 0
```

and the final JPEG must be identically oriented.

New timing:

```text
directOrientedCommitElapsedMs
```

The native strip task now includes the post-pair ARGB destination-layout copy, so a modest increase in `fullColorRenderElapsedMs` / `nativeColorTaskElapsedMsSum` is expected. Acceptance is based on **net render-core improvement**, not on keeping the colour-stage number numerically identical.

## Build identity

```text
package target:
M9Cam_v0_7ZA_TC20NATIVE1B_ORIENT1A.zip

version:
1.15-m9modern7r38luma24fb1primary24tc20native1borient1a

route:
M9-PRIMARY2.4-TC20NATIVE1B-ORIENT1A

renderer schema:
m9cam.renderer.r38.h25tg1.full12.android.v16.primary2p4tc20native1borient1a
```
