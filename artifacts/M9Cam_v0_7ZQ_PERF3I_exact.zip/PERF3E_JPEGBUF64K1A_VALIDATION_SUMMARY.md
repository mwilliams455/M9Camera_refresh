# PERF3E JPEGBUF64K1A validation summary

## Parent
Direct derivative of:
`M9Cam_v0_7ZL_PRIMARY2_5_PERF3D_JPEG1A_TC20LUMA8A_COLOR8A_DirectFrom07ZK.zip`

## Device evidence motivating this branch
Five rapid PERF3D/JPEG1A PRIMARY sidecars from 2026-09-01 showed median JPEG save decomposition:
- jpegEncodeWriteElapsedMs: 283 ms
- jpegCompressElapsedMs: 235.46 ms
- jpegCompressCpuApproxElapsedMs: 192.21 ms
- jpegStreamWriteElapsedMs: 43.25 ms
- jpegExifSaveElapsedMs: 29.84 ms
- jpegFileOpenElapsedMs: 6.11 ms
- jpegRecycleElapsedMs: 13.12 ms
- jpegStreamWriteCalls: 5121

The burst also showed broad device-load/thermal slowdown outside JPEG (median fullColor 525 ms; native colour worker wall 437.80 ms; final DNG save spike 1439 ms), so JPEG is not treated as the sole cause of the slower end-to-end run.

## PERF3E execution change
Only the JPEG byte transport is changed:

`Bitmap.compress()` -> `BufferedOutputStream(64 KiB)` -> timing wrapper -> original raw file OutputStream

The timing wrapper now sits underneath the buffer so `jpegStreamWriteCalls` measures actual underlying file writes rather than the encoder's ~5000 small write calls.

## Quality/parity contract
Unchanged:
- 3072x4096 / 12 MP output
- `Bitmap.CompressFormat.JPEG`
- JPEG quality 95
- source bitmap/pixels
- EXIF setup and `saveAttributes()` path
- Cobalt/H25/HSM/M9 bridge/TC20/SAT3/curve02/BT.601/TG1 photographic pipeline
- COLOR8A worker count and frozen scalar colour kernel
- TC20LUMA8A math/order
- DNGASYNC, queue, timing freeze and ownership architecture

A BufferedOutputStream changes only batching of writes. It does not change the values or ordering of bytes supplied by `Bitmap.compress()`.

## Static/host validation
- apply patch Python compile: PASS
- verifier Python compile: PASS
- PERF3E buffer source guard: PASS
- retained frozen native-function source guard: PASS
- full `m9color_jni.cpp` SHA256 identical to PERF3D parent:
  `22bfb9cd18b2816928c5946eca66b394ef2031a85f595f98e46c3b73bbe550f7`
- frozen photographic native function hashes retained:
  - applyHsm: `7f4e1e8224d976b65be68ae21fe5fcd3d5ef43d461507ea33f87c2007fffbe5a`
  - cameraToSrgbLuma: `d2247d137a35f6ef0729df2977c494f30d54da438ed0b98197a529bdb7bbe382`
  - cameraToM9: `a3d216769a59128825c44b5b69f7f9d9219dddb76c43e00bb462293afedf2bc9`
  - m9CurvePixel: `0c88877b5d50cf409bae84fe95e6e172184f2e7f0c39352b763fd5dafa7a9d5f`
  - renderStripScalar: `c157a252e4d29657ff000f3241c21a3c9cb89dfa57769b0579e6f22ac928faa0`
  - orientCompletedStrip: `534221e756b6d5af9e54312dfad441e25120d2941e288473d7b5aeda28faa51d`
- host BufferedOutputStream transport test wrote 3,333,333 deterministic bytes using identical chunk sequence; buffered and unbuffered files were byte-for-byte identical and SHA256-identical: PASS

## Build identity
`1.28-m9modern7r38luma24fb1primary25perf3ejpegbuf64k1atc20luma8acolor8adngasync1a`

Diagnostics:
- `performanceForensics=PERF3E_JPEGBUF64K1A_TC20LUMA8A_COLOR8A`
- `jpegForensics=PERF3E_JPEGBUF64K1A_EXACT_BYTES`

## Expected device result
Primary criterion:
- `jpegStreamWriteCalls` should fall from ~4500-5300 to tens of underlying writes.

Secondary criterion:
- `jpegStreamWriteElapsedMs` should materially fall if syscall/write-call overhead was significant.

Expected unchanged:
- `jpegCompressCpuApproxElapsedMs` remains around the same range because the JPEG encoder and quality are unchanged.

No JPEG encoder swap or quality-reducing optimization is part of PERF3E.
