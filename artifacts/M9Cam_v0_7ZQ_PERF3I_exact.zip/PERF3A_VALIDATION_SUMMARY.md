# M9Cam v0.7ZI PRIMARY2.5 / PERF3A — Timing-Only Performance Forensics

## Base

Direct base: `M9Cam_v0_7ZH_DNGASYNC1A_FIX1_METADATA_ONLY.zip` (promoted).

PERF3A does not change photographic output or execution architecture. It adds narrow timing probes to determine which part of the remaining ~0.8 s M9 JPEG/render critical path should be optimized next.

## Frozen behavior

Unchanged:

- renderer schema `m9cam.renderer.r38.h25tg1.full12.android.v19.primary2p4tc20native1borient1anormnative1acolornative2afix1`
- R3.8 / H25 / TG1
- TC20NATIVE1B decision math and Java gain/headroom decision
- SAT3 M06/M07
- curve02
- exact source-horizontal BT.601 4:2:2
- ORIENT1A
- NORMNATIVE1A
- METAFREEZE1A
- COLORNATIVE2A-FIX1 scalar kernel
- 384-row colour blocks
- 4 native colour workers
- JPEG quality 95
- NAME1A / QUEUE1B / TIMINGFREEZE1A / DNGASYNC1A
- zero-copy Photon RAW ownership transfer
- DNG bounded async worker and synchronous preservation fallback
- exposure policy and LUMA2.4-SPATIAL2-FB1

Timing schema remains `m9cam.primarytiming.v5.dngasync1a`.

Build identity is diagnostic-only:

`1.24-m9modern7r38luma24fb1primary25perf3adngasync1a`

## New COLORNATIVE2A diagnostics

PERF3A keeps the existing `fullColorRenderElapsedMs`, `nativeColorTaskElapsedMsSum`, `nativeColorJniElapsedMsSum` and direct Bitmap commit telemetry, and adds:

- `nativeColorBitmapCreateElapsedMs`
- `nativeColorOpenCvTransferElapsedMsSum`
- `nativeColorScratchPrepElapsedMsSum`
- `nativeColorInputCopyElapsedMsSum`
- `nativeColorWorkerWallElapsedMsSum`
- `nativeColorWorkerMaxElapsedMsSum`
- `nativeColorThreadOverheadApproxMsSum`
- `nativeColorOrientationElapsedMsSum`
- `nativeColorOutputCopyElapsedMsSum`
- `nativeColorNativeTotalElapsedMsSum`
- `performanceForensics = PERF3A_TIMING_ONLY`

Interpretation:

- `OpenCvTransfer` = `cam16.get(...)` into the reusable Java colour block.
- `InputCopy` = JNI `GetShortArrayRegion` into native scratch.
- `WorkerWall` = wall time from first native worker spawn through all joins for each block, summed over eight blocks.
- `WorkerMax` = slowest scalar worker duration per block, summed over eight blocks.
- `ThreadOverheadApprox = WorkerWall - WorkerMax`; this is the best direct estimate of repeated spawn/join/scheduling overhead plus non-kernel wall overhead. It is not CPU-time sum.
- `Orientation` = ORIENT1A completed-RGB strip mapping inside native.
- `OutputCopy` = JNI `SetIntArrayRegion` back into Java `argbBlock`.
- `directOrientedCommitElapsedMs` = Java `Bitmap.setPixels(...)` commits, already present.

This split is intended to answer whether the next safe optimization should be persistent native workers, copy elimination, orientation/Bitmap transfer work, or the scalar pixel kernel itself.

## New TC20 diagnostics

Added:

- `tc20NativeScratchPrepElapsedMs`
- `tc20NativeInputCopyElapsedMs`
- `tc20NativeLumaPopulationElapsedMs`
- `tc20NativeTotalWeightElapsedMs`
- `tc20NativeWeightedMedianElapsedMs`
- `tc20NativeP98ElapsedMs`
- `tc20NativeScalarTotalElapsedMs`

The luma population timer contains the frozen H25/HSM -> sRGB-linear luma computation. Median/P98 timers isolate selection work without changing pivoting, comparisons, weighting or ranks.

## Static validation

PASS:

- `apply-m9cam-v0.7-r35-parity.py` Python compile
- `verify-m9cam-v0.7-r35.py` Python compile
- `m9color_jni.cpp` C++17 syntax-only compile with JDK JNI headers
- PERF3A source guard

Exact promoted function hashes retained:

- `applyHsm` — `7f4e1e8224d976b65be68ae21fe5fcd3d5ef43d461507ea33f87c2007fffbe5a`
- `cameraToSrgbLuma` — `d2247d137a35f6ef0729df2977c494f30d54da438ed0b98197a529bdb7bbe382`
- `cameraToM9` — `a3d216769a59128825c44b5b69f7f9d9219dddb76c43e00bb462293afedf2bc9`
- `m9CurvePixel` — `0c88877b5d50cf409bae84fe95e6e172184f2e7f0c39352b763fd5dafa7a9d5f`
- `renderStripScalar` — `c157a252e4d29657ff000f3241c21a3c9cb89dfa57769b0579e6f22ac928faa0`
- `orientCompletedStrip` — `534221e756b6d5af9e54312dfad441e25120d2941e288473d7b5aeda28faa51d`

These are byte-identical to promoted v0.7ZH.

## Device gate

Recommended minimum:

1. Install/build normally.
2. Take 4 ordinary single shots across typical scenes.
3. Take one short rapid burst sufficient to create queue wait but not intentionally force repeated QUEUE1B refusal.
4. Return the resulting `_M9_PRIMARY.json` files; logcat is useful but not required unless a crash/build/runtime issue appears.

For the first analysis, prioritize these fields:

- `fullColorRenderElapsedMs`
- `nativeColorJniElapsedMsSum`
- all new `nativeColor*Elapsed*` fields
- `directOrientedCommitElapsedMs`
- `meterTc20ElapsedMs`
- `nativeTc20ElapsedMs`
- all new `tc20Native*ElapsedMs` fields
- `jpegEncodeWriteElapsedMs`
- `renderCoreElapsedMs`
- `renderElapsedMs`
- `_M9_PRIMARY.json`: `queueWaitElapsedMs`, `workerElapsedMs`, DNG async fields

## Decision rules after device data

- If `nativeColorThreadOverheadApproxMsSum` is large (roughly >= 30–50 ms typical), test persistent/reused native workers before NEON.
- If JNI/OpenCV/output/Bitmap copies are large in aggregate (roughly >= 50–80 ms), pursue a copy-boundary reduction while preserving ART GC safety and ORIENT1A.
- If `WorkerMax` dominates and transfer/thread overhead is small, the scalar H25/HSM pixel kernel is the correct next target; only then evaluate exact-parity ARM64/NEON.
- If TC20 `LumaPopulation` dominates, optimize/reuse that frozen H25/HSM traversal first. If median/P98 dominate, optimize selection/data structures without changing the result.
- JPEG remains a separate target unless its encode/write time is consistently comparable to or larger than the winning colour/TC20 opportunity.

## Profiling overhead note

PERF3A adds `steady_clock`/`System.nanoTime` calls. Small timing overhead is expected and this build should not itself be promoted as the final performance branch. The purpose is to choose the next optimization with evidence.
