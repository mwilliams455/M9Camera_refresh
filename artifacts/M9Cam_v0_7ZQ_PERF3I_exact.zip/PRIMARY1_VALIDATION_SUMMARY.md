# M9 PRIMARY1 validation summary

Build target: `1.00-m9modern7r38luma24fb1primary1`

## Purpose
Promote M9Modern from the FULL12-2 ASYNC1 sidecar architecture into the Photon finished-image route, while preserving capture re-arm and eliminating ASYNC1's second full-resolution RAW copy.

## Core ownership change
Photon already creates an independent Allocator-backed `ImageFrame` in `SaverImplementation.getFrame()`. PRIMARY1 transfers that existing frame directly out of `IMAGE_BUFFER`, freezes capture diagnostics, sets `bufferLock=false`, and then queues M9 processing.

Active route:

`Photon ImageFrame -> freeze _M9.json -> bufferLock=false -> PRIMARY1 queue -> M9 primary JPEG -> development DNG -> close frame`

No active `DefaultSaver` call to `detachForBackground()` remains.

## Primary output change
The M9 output is now the normal Photon finished image:

`IMG_....jpg`

rather than the temporary sidecar:

`IMG_...._M9.jpg`

The untouched DNG and diagnostics remain development instrumentation.

## Performance instrumentation
Capture-specific `_M9_PRIMARY.json` contains queue/worker/DNG timing plus renderer stage timing. Renderer timing is intentionally coarse enough not to perturb every pixel:

- RAW normalization/tail scan
- OpenCV EA demosaic
- color-context setup
- 1600-side meter + TC20
- fused H25/M9/SAT3/curve02/BT.601/TG1 full-resolution loop
- orientation
- JPEG encode/write

## Frozen invariants
H25/S85/V100, TC20, SAT3 M06/M07, curve02, exact BT.601 4:2:2, TG1, LUMA2.4-SPATIAL2, FB1 +0.75 EV ceiling, M9Modern v0.6.1 policy, 1600-side TC20 meter, 24-row renderer, JPEG quality 95.

## Packaging validation performed

- apply/verifier Python syntax: PASS
- ASYNC1 -> PRIMARY1 route replacement synthetic test: PASS
- patch idempotence test: PASS
- semantic verifier: 94 checks PASS
- direct ownership assertion: PASS
- no `detachForBackground` in active `DefaultSaver` route: PASS
- `bufferLock=false` before PRIMARY1 enqueue: PASS
- single worker / bounded queue: PASS
- primary renderer uses `THREAD_PRIORITY_DEFAULT`: PASS
- normal `.jpg` primary filename assertion: PASS
- primary JPEG scheduled before development DNG: PASS
- capture JSON frozen before lock release: PASS
- final timing sidecar is capture-path-specific, not shared static state: PASS
- renderer Java parse smoke: no Java syntax errors detected before expected missing Android/OpenCV symbol errors
- frozen H25/TG1/TC20/FB1 constant audit: PASS via verifier

Android/GitHub remains the actual full compile gate.

## Device gate
1. Build succeeds.
2. Capture re-arms without waiting for the M9 JPEG.
3. Normal `IMG_....jpg` is the M9 render.
4. No `_M9.jpg` duplicate is produced.
5. Native landscape/portrait dimensions and orientation are correct.
6. DNG + `_M9.json` + `_M9_PRIMARY.json` remain capture-specific.
7. Two rapid captures do not cross-wire filenames or diagnostics.
8. No crash/OOM/queue corruption.
9. Visual output matches the frozen FULL12-2 ASYNC1/FIX1 reference.
10. `ownershipTransferElapsedMs + captureMetadataElapsedMs` is materially below the prior 608 ms ASYNC1 foreground handoff measurement.
