# PERF3F EXIFASYNC1A validation summary

## Parent
Direct derivative of promoted:
`M9Cam_v0_7ZM_PRIMARY2_5_PERF3E_JPEGBUF64K1A_TC20LUMA8A_COLOR8A_DirectFrom07ZL.zip`

Parent SHA256:
`247d569a2556f91b32999895cbd321e27fc9e2a9893adba75cb360c97ce5115c`

## Investigation result
PERF3E showed the remaining JPEG metadata cost at roughly 23-34 ms per tested frame, with a median around 26 ms.

The current M9 path was traced as:

`M9R35Renderer -> ImageSaver.Util.saveBitmapAsJPG() -> Bitmap.compress/close/recycle -> ParseExif.setAllAttributes() -> ExifInterface.saveAttributes() -> return -> M9PrimaryRenderQueue -> notifyImageSavedStatus(true, jpegPath)`

PhotonCamera dev source was also inspected for the listener implementation. `notifyImageSavedStatus(true, path)` immediately triggers the media scanner for `Uri.fromFile(path)` and updates the gallery thumbnail. Therefore simply returning from the renderer before EXIF and leaving the old notification in M9PrimaryRenderQueue would create a real publication race.

Safe boundary selected:

`quality-95 JPEG payload -> bounded EXIF finalizer -> saveAttributes() -> JPEG media scan/gallery notification`

The DNG stage also waits for the JPEG-finalization ticket before announcing the DNG, preserving the parent's JPEG-before-DNG publication ordering.

## PERF3F execution change
The render worker still performs the exact retained JPEG payload path:

`Bitmap.compress(JPEG, quality=95) -> 64 KiB BufferedOutputStream -> existing file OutputStream -> flush/close -> Bitmap.recycle()`

It then submits `{jpegPath, ParseExif.ExifData, ProcessingEventsListener}` to `M9JpegFinalizeQueue`.

`M9JpegFinalizeQueue`:
- one worker: `M9JpegExifIO`;
- `MAX_PENDING=2`;
- performs the same Photon metadata operations: `ParseExif.setAllAttributes()` then `ExifInterface.saveAttributes()`;
- calls `notifyImageSavedStatus(true, jpegPath)` only after EXIF completion;
- on queue saturation, runs the same EXIF finalization synchronously on `M9PrimaryRenderer` as a preservation fallback;
- never intentionally drops metadata.

The DNG/timing stage holds a finalization ticket. Before final timing is frozen it waits for completion so `jpegSaved` means the complete JPEG including EXIF, not merely an encoded payload.

## Quality/parity contract
Unchanged:
- 12 MP 3072x4096 output;
- `Bitmap.CompressFormat.JPEG`;
- JPEG quality 95;
- Android `Bitmap.compress` encoder;
- 64 KiB JPEG transport buffer;
- source bitmap/pixels;
- EXIF tag generation (`ParseExif.parse`);
- EXIF application (`ParseExif.setAllAttributes` + `saveAttributes`);
- Cobalt/H25/HSM/M9 bridge/TC20/SAT3/curve02/BT.601/TG1 photographic pipeline;
- COLOR8A worker count and frozen scalar colour kernel;
- TC20LUMA8A math/order;
- DNGASYNC ownership architecture;
- QUEUE1B capture admission;
- NAME1A filenames;
- exposure behavior.

No encoder swap, quality change, chroma-subsampling change, render-resolution change, fast-math, or photographic-math change is present.

## Publication-order contract
Normal path:

`JPEG payload close -> EXIF saveAttributes -> JPEG notify/media scan -> DNG notify/media scan -> timing freeze`

If the EXIF queue is saturated:

`JPEG payload close -> synchronous EXIF saveAttributes -> JPEG notify/media scan -> DNG path`

Thus a partially finalized JPEG is never intentionally announced to Photon/Gallery, and DNG publication cannot overtake JPEG finalization.

## New diagnostics
Renderer / final PRIMARY diagnostics can include:
- `jpegSaveHelperBoundary=payload_before_exifasync1a`
- `jpegPayloadSaveHelperElapsedMs`
- `jpegExifAsyncAccepted`
- `jpegExifSyncFallback`
- `jpegExifFinalizeSuccess`
- `jpegExifQueueDepthAtSubmit`
- `jpegExifActiveCountAtSubmit`
- `jpegExifQueueCapacity`
- `jpegExifQueueWaitElapsedMs`
- `jpegExifSetupElapsedMs`
- `jpegExifSaveElapsedMs`
- `jpegExifFinalizeElapsedMs`
- `jpegPublicationElapsedMs`
- `jpegExifFallbackCountSnapshot`
- `jpegPublicationAfterExif=true`
- `jpegExifFinalizerThread`

Primary timing schema advances to:
`m9cam.primarytiming.v6.exifasync1a.dngasync1a`

Top-level timing also declares:
- `jpegExifFinalizationOffRenderWorker=true`
- `jpegPublicationAfterExif=true`
- `jpegExifFinalizationPolicy=bounded_single_worker_with_sync_preservation_fallback`

## Static / host validation
PASS:
- apply patch Python syntax compile;
- verifier Python syntax compile;
- PERF3F source guard;
- `M9JpegFinalizeQueue.java` javac syntax/type smoke with minimal Android/Photon stubs;
- modified `M9PrimaryRenderQueue.java` javac syntax/type smoke with minimal stubs;
- source guard confirms JPEG notification is absent from the render queue and present only after EXIF in the finalizer;
- source guard confirms DNG publication is ordered after the JPEG finalizer latch;
- source guard confirms `jpegSaved` is derived from finalizer success before final timing freeze;
- full `m9color_jni.cpp` SHA256 is identical to PERF3E parent:
  `22bfb9cd18b2816928c5946eca66b394ef2031a85f595f98e46c3b73bbe550f7`.

The frozen native photographic function hashes therefore remain inherited from v2.61 unchanged.

## Build identity
`1.29-m9modern7r38luma24fb1primary25perf3fexifasync1ajpegbuf64k1atc20luma8acolor8adngasync1a`

Performance marker:
`PERF3F_EXIFASYNC1A_JPEGBUF64K1A_TC20LUMA8A_COLOR8A`

JPEG forensic marker:
`PERF3F_EXIFASYNC1A_JPEGBUF64K1A_EXACT_PAYLOAD`

## Expected device result
Healthy standalone / cooled burst:
- `jpegExifAsyncAccepted=true`;
- `jpegExifSyncFallback=false`;
- `jpegExifFinalizeSuccess=true`;
- `jpegPublicationAfterExif=true`;
- `jpegSaved=true` and `dngSaved=true`;
- `jpegCompressCpuApproxElapsedMs` remains in the PERF3E class;
- `jpegStreamWriteCalls` remains in the tens, not thousands;
- render-worker occupancy should improve by roughly the old EXIF setup+save cost (~25-30 ms typical), all else equal.

The gain is intentionally modest. Promotion requires correctness first; a 25 ms speedup is not worth metadata corruption, gallery races, or any photographic-quality change.

## Device test protocol
1. One standalone frame after the phone has settled.
2. Confirm final JPEG exists, opens normally, has expected EXIF, and appears in gallery.
3. Confirm untouched DNG exists and appears after the JPEG publication path.
4. Inspect PRIMARY JSON for all EXIFASYNC fields and `jpegSaved=true` / `dngSaved=true`.
5. Capture 4-5 rapid frames after cooling.
6. Expect `jpegExifAsyncAccepted=true`, no fallback, and no missing JPEG/DNG pairs.
7. Compare `workerElapsedMs`, `renderElapsedMs`, `jpegPayloadSaveHelperElapsedMs`, and the finalizer timings against PERF3E stage-level medians.
8. If a metadata failure, missing EXIF, missing gallery image, filename mismatch, or publication-order issue occurs: reject PERF3F and return to v0.7ZM.
