# PRIMARY2.2D SCALE8 validation summary

Date: 2026-08-31

## Reason for branch

PRIMARY2.2C device result did not beat the validated PRIMARY2.2 colour baseline.

Latest PRIMARY2.2C device frame (IMG_20260831_145045):

- fullColorRenderElapsedMs = 2175 ms
- renderElapsedMs = 4449 ms
- captureMetadataElapsedMs = 1595 ms
- JPEG-visible diagnostic + render path ~= 6044 ms

Validated PRIMARY2.2 reference frame:

- fullColorRenderElapsedMs = 1675 ms
- renderElapsedMs = 3296 ms

PRIMARY2.2C is therefore not promoted. UNIT16LUT1/M9FUSE1/HSMCONST1 are not carried into this branch.

## PRIMARY2.2D change

PRIMARY2.2D branches directly from validated v0.7T PRIMARY2.2.

Only the bounded pure-Java full-colour worker ceiling changes:

```text
PRIMARY2.2: max 4 colour workers
PRIMARY2.2D: max 8 colour workers (bounded by Runtime.availableProcessors())
```

The Xiaomi 15 Ultra class target has enough application-visible cores to make worker scaling worth measuring now that arithmetic micro-optimizations are within device run-to-run/thermal variance.

Unchanged:

- 24-row streaming strip geometry
- serialized OpenCV Mat.get access
- ordered Bitmap writes after worker join
- RAW normalization worker count (4)
- H25/HSM arithmetic
- precomposed M9 bridge from PRIMARY2.2
- SAT3 M06/M07
- curve02
- exact horizontal BT.601 4:2:2 pair arithmetic
- TG1
- TC20
- LUMA2.4-SPATIAL2-FB1
- zero-copy PRIMARY1 ImageFrame ownership

## Static arithmetic parity

The following PRIMARY2.2 hot-loop bodies are byte-identical in source between v0.7T and PRIMARY2.2D:

- ColorStripWorker.render
- cameraToHsmXyz50
- cameraToM9
- m9CurvePixel
- applyHsm
- hsv6ToRgbWrapped

Only scheduling ceiling and diagnostic/build identity changed.

## Device decision rule

Compare against the best validated PRIMARY2.2 colour result of 1675 ms, but record at least two frames because recent runs show substantial CPU/thermal variance.

Interpretation:

- <= 1300 ms: strong SCALE8 pass; continue Java scheduling work
- 1300-1500 ms: useful pass
- 1500-1700 ms: modest scaling / near Java ceiling
- >= 1700 ms on repeated frames: worker scaling does not solve the bottleneck; proceed to scalar JNI/C++ HSM colour core

Also record `parallelColorWorkers` to confirm the device exposed 8 workers.

## Build identity

- route: M9-PRIMARY2.2D
- renderer schema: m9cam.renderer.r38.h25tg1.full12.android.v9.primary2p2d
- version: 1.05-m9modern7r38luma24fb1primary22d
- colour mode: precomposed_pp_to_m9_hsm_wrap_exact1_scale8
