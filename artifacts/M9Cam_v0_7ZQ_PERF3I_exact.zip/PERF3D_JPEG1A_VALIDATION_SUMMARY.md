# PERF3D JPEG1A Validation Summary

## Device evidence entering PERF3D

PERF3C retained COLOR8A and parallelized only TC20 H25/HSM-to-sRGB luma population.
Using the rapid captures from the device test, compared with the preceding COLOR8A rapid baseline:

| Stage | PERF3B COLOR8A | PERF3C TC20LUMA8A | Change |
|---|---:|---:|---:|
| native TC20 | 124.0 ms | 95.5 ms | -23.0% |
| TC20 luma population | 84.9 ms | 44.6 ms | -47.5% |
| total TC20 | 164.0 ms | 140.5 ms | -14.3% |
| full colour | 338.0 ms | 374.5 ms | +10.8% in this run |
| JPEG encode/write | 149.0 ms | 220.5 ms | +48.0% in this run |
| render core | 581.0 ms | 600.0 ms | +3.3% in this run |
| render worker | 783.0 ms | 851.5 ms | +8.7% in this run |

Interpretation: the TC20 optimization itself succeeded. The whole-frame run did not improve because
other later stages were slower. DNG save also rose from roughly 504 ms to 632.5 ms in the rapid set,
which is evidence that the test environment/storage state was not directly comparable at the I/O level.
TC20 child threads are joined before colour/JPEG execution, so the combined JPEG field needs internal
measurement before attributing its variance to encoding CPU, storage or EXIF handling.

## PERF3D change

PERF3D adds timing only to the exact Photon JPEG helper sequence:

1. Files.newOutputStream()
2. Bitmap.compress(JPEG, quality 95, stream)
3. stream flush
4. stream close
5. bitmap recycle
6. ParseExif.setAllAttributes()
7. ExifInterface.saveAttributes()

The output stream is wrapped only to measure time spent forwarding writes to the original underlying
stream. Bytes, JPEG quality and call order are not changed.

## Frozen renderer

No changes are made to:
- H25/HSM arithmetic
- M9 bridge / SAT3 / curve02
- exact BT.601 4:2:2 / TG1
- TC20 weighted median/P98/gain decisions
- COLOR8A scalar pixel kernel
- exposure or LUMA2.4 feedback
- queue/ownership/DNGASYNC/TIMINGFREEZE/METAFREEZE behavior
- JPEG quality or EXIF values

## Required device evidence

Take one ordinary frame plus a short rapid sequence. Upload `_M9_PRIMARY.json` sidecars.
The decision fields are:

- jpegCompressElapsedMs
- jpegStreamWriteElapsedMs
- jpegCompressCpuApproxElapsedMs
- jpegExifSetupElapsedMs
- jpegExifSaveElapsedMs
- jpegFlushElapsedMs / jpegCloseElapsedMs
- jpegStreamWriteCalls
- jpegEncodeWriteElapsedMs (existing outer control)

Do not optimize the JPEG path until these fields identify the dominant component across several frames.
