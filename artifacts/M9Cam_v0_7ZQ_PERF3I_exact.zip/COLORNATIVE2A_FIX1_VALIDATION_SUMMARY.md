# COLORNATIVE2A FIX1 validation summary

## Device failure identified

The original v0.7ZD COLORNATIVE2A build launched and entered photo processing, but every attempted frame crashed in `libm9color.so` from the `M9PrimaryRender` path. The Android tombstone reports `SIGSEGV`, `SEGV_MAPERR`, fault address `0x0`, read, with the top two frames inside `libm9color.so`. Register state at the crash contains `x2=0x60000` and `x3=0x1000`, exactly matching a COLORNATIVE2A native worker slice of 96 rows x 4096 pixels. Input/output pointer registers are null.

## Root cause

`renderBlockParallel()` populated JNI-caller `thread_local` vectors:

```cpp
thread_local std::vector<jshort> camScratch;
thread_local std::vector<jint> argbScratch;
```

but the child `std::thread` lambda referred to `camScratch.data()` and `argbScratch.data()` directly. `thread_local` objects have a distinct instance per native thread. Each newly spawned worker therefore observed its own empty vector, and `data()` was null.

This bug was not exercised by the original host row-partition parity harness because that harness passed ordinary `std::vector` pointers directly.

## FIX1

Immediately after sizing/copying the JNI caller scratch, FIX1 freezes:

```cpp
const jshort* const camBase = camScratch.data();
jint* const argbBase = argbScratch.data();
```

Each worker captures those ordinary pointer values and renders disjoint row ranges from them. The caller vectors are not resized until all threads join, so pointer lifetime is stable for the entire native call.

No photographic or scheduling mathematics changed. Retained exactly:

- 384-row native colour blocks;
- 8 JNI colour calls for 4096x3072;
- 4 native workers per full block;
- exact scalar FIX7/PRIMARY2.2 H25/HSM + M9 bridge + SAT3 + curve02 + BT.601/TG1 kernel;
- source-horizontal 4:2:2 pairing;
- ORIENT1A destination mapping;
- TC20NATIVE1B;
- NORMNATIVE1A;
- METAFREEZE1A;
- LUMA2.4-SPATIAL2-FB1 exposure behavior.

## Device gate

First take one ordinary landscape frame. Success requires: app remains alive, JPEG + DNG save, `_M9.json` eventually appears, `_M9_PRIMARY.json` appears, `nativeColorCalls == 8`, `nativeColorWorkersUsed == 4`, and `orientationElapsedMs == 0`. Then take one portrait frame. Only after both pass should rapid-shot queue testing resume.

## Build identity

```text
package:
M9Cam_v0_7ZD_FIX1_COLORNATIVE2A_TC20NATIVE1B_ORIENT1A_NORMNATIVE1A_METAFREEZE1A.zip

versionName:
1.19-m9modern7r38luma24fb1primary24tc20native1borient1anormnative1ametafreeze1acolornative2afix1

renderer schema:
m9cam.renderer.r38.h25tg1.full12.android.v19.primary2p4tc20native1borient1anormnative1acolornative2afix1

route:
M9-PRIMARY2.4-TC20NATIVE1B-ORIENT1A-NORMNATIVE1A-METAFREEZE1A-COLORNATIVE2A-FIX1
```
