# Leica M9 Project — R3.8 H25 validation report

## Decision

The leading sensor-adapter candidate is now:

```text
Cobalt Xiaomi ProfileHueSatMap
Hue        = 25%
Saturation = 85%
Value      = 100%
```

This is a candidate promotion from R3.7 H100/S85/V100, not a final freeze.
The Leica core is unchanged: M9 bridge, TC20, SAT3 M06/M07, curve02, exact
BT.601 horizontal 4:2:2 and TG1 remain fixed.

## Why H25

Three independent-ish checks now point away from H100 and toward the low end
of the 0/25/50/75/100 bank.

### 1. Real daylight diagnostic regions

Relative to current H100, H25 moves the observed problem families without
material desaturation:

```text
green / yellow-green:  +6.80 deg hue, saturation ratio 0.996
warm / brown / cream:   -2.80 deg hue, saturation ratio 0.995
red:                    +1.35 deg hue, saturation ratio 0.996
blue / sky:             -2.60 deg hue, saturation ratio 1.021
```

The bank is monotonic. The correction is therefore behaving like a genuine
hue-axis change rather than an accidental saturation reduction.

### 2. Decoded Cobalt M9 Standard synthetic containment

The Cobalt M9 Low/Standard/High 32^3 ProPhoto/gamma-1.8 RGBTables are used only
as a synthetic containment reference, never as a fitted renderer target.
Weighted Standard-table hue error across a broad synthetic colour grid:

```text
H25   5.33 deg   <- best
H50   5.70 deg
H00   6.32 deg
H75   6.89 deg
H100  9.46 deg   <- worst
```

This independently rejects full H100 as the strongest universal front-end
choice and places H25/H50 in the useful range.

### 3. Same-RAW Lightroom + Cobalt M9 Standard reference

The old v2.5 package contains the actual same-RAW reference as the fourth panel
of `180145_v25_comparison.jpg`. The reference panel was recovered and compared
against the current renderer using the same `IMG_20260826_180145.dng`.

Because the reference is M9 Standard, the decisive sensor-adapter cross-check
uses the authentic SAT2 Standard M04/M05 pair rather than the user-preferred
SAT3 colourful pair. Balanced semantic hue errors (skin, blue shirt, gray
background and brown hair) are:

```text
SAT2 + H25   1.40 deg   <- best
SAT2 + H00   1.50 deg
SAT2 + H50   2.08 deg
SAT2 + H75   3.18 deg
SAT2 + H100  4.27 deg   <- worst
```

SAT3 was also checked. Its additional creative hue movement flattens the low-end
ranking, but H100 remains clearly worst. This is why H25 is treated as a
sensor-adapter decision while SAT3 remains the preferred colourful Leica mode.

## Production-path smoke regression

Unlike the isolation bank, this pass recomputes TC20 after changing HSM hue
strength, matching the way a real R3.8 build will behave.

Six priority 2026-08-30 frames:

```text
median TC20 gain ratio H25/H100: 1.0068
range:                           1.0000 .. 1.0143
median RGB change:               1.88 code values / 255
```

Nine fixed OpenCamera regression DNGs:

```text
median TC20 gain ratio H25/H100: 1.0000
range:                           0.9917 .. 1.0016
median RGB change:               1.23 code values / 255
```

Thus H25 does not materially disturb the accepted exposure normalization.
All 15 smoke-regression frames were above 4500 K, so TG1 was off. This means
this pass does NOT close tungsten compatibility.

## Important remaining gate

TG1 was tuned while H100 was upstream. H25 reduces a substantial source of
selective hue rotation before TG1, so the tungsten guard must be revalidated
with real warm-light RAWs before R3.8 can be frozen.

TG1 is intentionally unchanged in the Android field-test candidate. Changing
HSM hue and TG1 simultaneously would destroy causal isolation.
