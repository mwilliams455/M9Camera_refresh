# PRIMARY2.3 JNI1 FIX6 validation summary

Date: 2026-08-31

## Device-log finding

The supplied Photon log materially changes the failure classification.

The latest recorded process at 18:05 successfully:

- created/configured the camera preview;
- completed FlowNet warmup;
- started and completed a one-frame RAW capture;
- saved the M9 metadata sidecar;
- entered the M9 primary renderer;
- initialized OpenCV and began renderer colour-context setup.

The Photon log then terminates abruptly at 18:05:35.829 during renderer setup. It contains no `FATAL EXCEPTION`, `AndroidRuntime`, `UnsatisfiedLinkError`, `dlopen`, `SIGSEGV`, `SIGABRT`, `m9color`, or JNI diagnostic line. This means the app-specific Photon logger did not capture the process-level failure, but the latest attempt is not an APK-start/CMake failure: it reaches the first M9 render.

FIX3 had no explicit log boundary around native loading/context/first-strip entry, so the exact JNI transition could not be localized from that file alone.

## FIX6 change

The photographic kernel is unchanged.

The JNI array-transfer wrapper is changed from long-lived managed-heap critical sections to ordinary JNI region copies backed by thread-local native scratch buffers:

- removed `GetPrimitiveArrayCritical` / `ReleasePrimitiveArrayCritical`;
- input: `GetShortArrayRegion` into thread-local `std::vector<jshort>`;
- output: native thread-local `std::vector<jint>` followed by `SetIntArrayRegion`;
- diagnostics: `SetLongArrayRegion`;
- four Java colour workers and 24-row strip geometry remain unchanged;
- one JNI render call per strip remains unchanged.

The thread-local buffers amortize allocation and avoid pinning managed arrays / constraining ART GC while the scalar H25/HSM strip kernel runs.

## New device diagnostics

FIX6 logs these boundaries explicitly:

1. `PRIMARY2.3 JNI1 FIX6 native load begin`
2. `PRIMARY2.3 JNI1 FIX6 native load ok; context create begin`
3. `PRIMARY2.3 JNI1 FIX6 native context created`
4. `PRIMARY2.3 JNI1 FIX6 first native strip begin`
5. `PRIMARY2.3 JNI1 FIX6 first native strip complete in ... ms`

The primary render queue now also identifies itself as `PRIMARY2.3 JNI1 FIX6` rather than retaining the old PRIMARY2.2 log label.

If a process-level failure remains, the last emitted boundary identifies the next exact target.

## Mathematical parity

The unchanged scalar colour kernel still reports:

```text
case0 hash=d8a41181af097d65 even=12148 edge=38679 nearWhite=3743
case1 hash=4fa72399bad9d8bb even=12669 edge=50029 nearWhite=7350
case2 hash=4186500ffb6b1f36 even=15143 edge=56958 nearWhite=10499
case3 hash=b9b94cc14c4f68ca even=16275 edge=59506 nearWhite=12253
aggregate=7e21b6ae4a9557ae pixels=24929 cases=4
```

This is the same aggregate fingerprint as JNI1/FIX1/FIX2/FIX3.

## JNI bridge smoke test

Unlike the earlier packages, FIX6 also has a host-JVM test that exercises the actual exported JNI entry points with four concurrent Java workers repeatedly calling the native strip function.

Result:

```text
JNI host bridge concurrent smoke PASS combined=5877c94789cdbe49
```

This does not substitute for Xiaomi/ART device validation, but it verifies the real JNI marshalling path rather than only calling `renderStripScalar()` directly from C++.

## Build identity

```text
route: M9-PRIMARY2.3-JNI1-FIX6
version: 1.11-m9modern7r38luma24fb1primary23jni1fix6
renderer schema: m9cam.renderer.r38.h25tg1.full12.android.v14.primary2p3jni1fix6
native mode: scalar_cpp_jni_parity1
native vectorization: disabled_scalar_baseline
```

## Device test rule

First gate is launch/preview. Then take one frame.

If it survives, take a second comparable frame and use `_M9_PRIMARY.json` for performance comparison.

If it dies, preserve the new Photon log. The last FIX6 JNI-boundary line will distinguish:

- library load failure;
- context creation failure;
- first native strip failure;
- failure after native strip return.
