# PRIMARY2.4 TC20NATIVE1B validation summary

## Purpose
Replace TC20NATIVE1A's global luma sort with a native weighted-selection implementation while preserving the accepted FIX7 / TC20NATIVE1A photographic decision.

This package is a direct derivative of the device-validated PRIMARY2.4 TC20NATIVE1A build. It intentionally leaves the rest of the renderer frozen. Only the meter algorithm changes.

## Runtime architecture
The renderer still:

1. normalizes the full RAW and derives the accepted RAW-tail guard from per-CFA histograms;
2. performs OpenCV EA demosaic;
3. creates the exact 1600-long-side `INTER_AREA` meter image;
4. transfers that meter image once to a `short[]`;
5. calls one JNI TC20 meter function;
6. uses Java for the accepted TC20 gain/headroom decision;
7. reuses the same native context for the unchanged FIX7 full-colour strip renderer.

The native meter still performs the same camera-to-luma transform as TC20NATIVE1A:

- H25/HSM camera-to-profile processing;
- XYZ50 -> D65 -> linear-sRGB luma proxy;
- valid population (`Y > 1e-5`).

What changed is the selection algorithm:

- weighted median now uses iterative three-way partition selection over the valid population rather than a full global sort;
- legacy P98 is recovered with rank selection instead of full sorting.

The Java-side gain definition is still the FIX7 definition. The RAW-tail guard is untouched.

## Deliberately frozen
No changes were made to:

- R3.8 exposure allocation or LUMA2.4-SPATIAL2-FB1 feedback;
- 1600-side meter resize and `INTER_AREA` semantics;
- `METER_TARGET`, `METER_CW`, TC20 headroom target, RAW-tail quantiles or adaptive tail logic;
- H25/HSM strengths;
- M9 bridge;
- SAT3 M06/M07;
- curve02;
- exact BT.601 horizontal 4:2:2 pairing;
- TG1;
- full-colour 24-row/four-worker native strip scheduling;
- JPEG/DNG output ordering or DNG contents.

## Host validation
### Native C++ syntax
`m9color_jni.cpp` compiled successfully with host `g++` using the JNI headers and the package's production arithmetic flags:

`-O3 -ffp-contract=off -fno-fast-math`

### Existing full-colour parity
The full-colour strip kernel was not modified. No full-colour arithmetic or scheduling code changed.

### TC20 Java-vs-JNI parity
`reference/Tc20Native1bParityTest.java` was compiled against the actual JNI implementation. On the deterministic synthetic test frame:

- Java weighted median: `0.46205609372066964`
- Native weighted median: `0.46205609372066964`
- Java P98: `0.82639677488795830`
- Native P98: `0.82639677488795830`
- valid population: `49082` on both paths

Result: **PASS**.

## New diagnostics
The renderer now reports:

- `tc20MeterMode = native_scalar_weightedselect_parity1b`
- `tc20NativeLibrary = m9color`
- `tc20Algorithm = weighted_selection_partition_p98_select`
- `tc20JavaGainMath = true`
- `meterResizeElapsedMs`
- `meterTransferElapsedMs`
- `nativeTc20ElapsedMs`

`meterTc20ElapsedMs` remains the wall-clock total for resize + transfer + native TC20 work.

## Device acceptance gate
This build is accepted only if:

1. app startup remains healthy;
2. JPEG and DNG both save normally;
3. `gain`, `baseMedianGain`, `legacyP98Proxy`, `tc20GuardGain` and visual rendering show no meaningful drift versus equivalent TC20NATIVE1A captures;
4. `meterTc20ElapsedMs` falls materially below the validated TC20NATIVE1A result (~280 ms);
5. no regression appears in full-colour timing.
