# PRIMARY2.2C Validation Summary

**Package label:** v0.7V PRIMARY2.2C UNIT16LUT1/M9FUSE1/HSMCONST1  
**Base:** exact device-passed v0.7T PRIMARY2.2 BRIDGE1/HSMFAST1  
**Build identity:** `1.05-m9modern7r38luma24fb1primary22c`  
**Renderer schema:** `m9cam.renderer.r38.h25tg1.full12.android.v8.primary2p2c`  
**Route:** `M9-PRIMARY2.2C`

## Why PRIMARY2.2C exists

The first PRIMARY2.2 device frame established the current best Java reference:

```text
fullColorRenderElapsedMs = 1675
renderElapsedMs          = 3296
normalizeRawElapsedMs    = 556
meterTc20ElapsedMs       = 630
```

PRIMARY2.2B SATFAST1/BTFAST1 did not demonstrate an on-device improvement on its first test:

```text
fullColorRenderElapsedMs = 1899
renderElapsedMs          = 3516
normalizeRawElapsedMs    = 353
meterTc20ElapsedMs       = 700
captureMetadataElapsedMs = 1431
```

Because those measurements were different captures/device states, this is not proof that either 2.2B micro-optimization is intrinsically slower. It is sufficient evidence not to promote 2.2B as the new performance reference. PRIMARY2.2C therefore branches from the exact passed PRIMARY2.2 architecture and targets a more fundamental remaining cost.

## Key finding: 37.7 million full-colour divisions per frame

The PRIMARY2.2 H25 input path executes:

```java
double r = (cam[c] & 0xffff) / 65535.0;
double g = (cam[c + 1] & 0xffff) / 65535.0;
double b = (cam[c + 2] & 0xffff) / 65535.0;
```

At 4096x3072 this is:

```text
12,582,912 pixels
x 3 channels
= 37,748,736 IEEE double divisions per full-colour render
```

Unlike a compiler reciprocal substitution, `q * (1/65535)` is not bit-identical for every q. PRIMARY2.2C therefore uses a 65,536-entry read-only table populated with the literal original division:

```java
UNIT16[q] = q / 65535.0;
```

The pixel loop then performs exact table lookup instead of division.

### UNIT16 parity

Exhaustive Java test:

```text
all unsigned q = 0..65535
bit-level mismatches = 0 / 65536
```

Directional host test over the same 37,748,736 conversions as one full-resolution frame:

```text
direct divide = 59.7 ms
UNIT16 lookup = 38.2 ms
lookup speedup = 1.56x
checksum bit-identical = true
```

Host timing is directional only; Android `fullColorRenderElapsedMs` remains authoritative.

## M9FUSE1: eliminate m90/m91 bridge array traffic

PRIMARY2.2 stored each pixel's three M9 bridge values into worker-owned `double[3]` arrays and immediately read them back in SAT3/curve02.

PRIMARY2.2C preserves the exact bridge dot-product order and exact `Math.rint(m9 * gain * RAW_MAX)` inputs, but keeps those three bridge values as local scalars and emits packed SAT3/curve02 RGB directly.

This removes:

```text
m90 + m91 worker arrays
3 bridge writes per pixel
3 immediate bridge reads per pixel
rgb0 + rgb1 worker arrays
3 curve-result writes per pixel
3 immediate curve-result reads per pixel
```

SAT3 M06/M07 coefficients, branch rule, shifts, clipping and curve02 bytes remain unchanged.

### M9FUSE1 parity

Deterministic Java test over 5,000,000 random PP RGB/matrix/gain combinations:

```text
packed RGB + branch/edge mismatches = 0
```

## HSMCONST1: exploit frozen calibration dimensions

`M9R35Calibration.load()` rejects any HSM dimensions except:

```text
90 x 30 x 1
```

PRIMARY2.2C therefore replaces per-pixel expressions:

```text
hd / 6.0 -> 15.0
sd - 1   -> 29.0
sd - 2   -> 28
hd - 1   -> 89
```

and removes `hd/sd` from the HSM call signature. This is not an approximation.

Deterministic Java test over 2,000,000 random RGB samples using a full 90x30x3 HSM table:

```text
bit-level RGB mismatches = 0
```

## Deliberate BTFAST1 rollback

PRIMARY2.2C does **not** retain PRIMARY2.2B's BTFAST1 lookup tables.

The exact PRIMARY2.2 scalar BT.601/TG1 arithmetic is restored:

```text
Cb/Cr TG1 multiplication
1.402 / .344136 / .714136 / 1.772 reconstruction
roundU8
horizontal two-pixel sharing
```

Reason: replacing a handful of ARM floating multiplies with table loads did not demonstrate a device win, and modern ARM multiply throughput can make such lookup substitutions counterproductive. SAT3 scalar packing is retained as part of M9FUSE1 because it removes array traffic without adding lookup memory.

## Frozen photographic pipeline

Unchanged:

```text
R3.8 H25 / S85 V100
Cobalt HSM data and interpolation mathematics
PRIMARY2.2 precomposed M9 bridge mathematics
TC20 algorithm
SAT3 M06/M07
curve02
exact BT.601 horizontal 4:2:2
TG1
RAW normalization arithmetic
4 RAW normalization workers
4 colour workers
24-row strips
OpenCV Bayer demosaic / 1600-side meter
JPEG 95
LUMA2.4-SPATIAL2-FB1
motion exposure policy
```

No photographic retuning is included.

## Validation evidence

```text
reference/primary22c_exact_hotloop_parity.java
reference/primary22c_exact_hotloop_parity.txt
reference/primary22c_source_guard.py
reference/primary22c_source_guard.txt
```

Results:

```text
UNIT16 exhaustive bit mismatches                0 / 65,536
M9 bridge+SAT3 fused packed mismatches          0 / 5,000,000
HSM fixed-dimension bit mismatches              0 / 2,000,000
```

## Device acceptance

The proper baseline remains PRIMARY2.2:

```text
fullColorRenderElapsedMs = 1675
renderElapsedMs          = 3296
```

For PRIMARY2.2C:

```text
<= 1500 ms full colour   meaningful new Java win
<= 1400 ms               strong result
<= 1300 ms               excellent; Java still has headroom
~1600-1700 ms            Java is nearing its practical ceiling
> 1700 ms                do not continue micro-optimizing Java blindly
```

If PRIMARY2.2C cannot materially beat PRIMARY2.2, the next renderer step should be scalar JNI/C++ for the H25/HSM + M9/SAT3 pixel core, establish exact parity, and only then investigate NEON SIMD.

The separate `captureMetadataElapsedMs` remains development instrumentation and should not be allowed to obscure the renderer result, although it continues to add roughly 1.4-1.6 s to current perceived JPEG latency.
