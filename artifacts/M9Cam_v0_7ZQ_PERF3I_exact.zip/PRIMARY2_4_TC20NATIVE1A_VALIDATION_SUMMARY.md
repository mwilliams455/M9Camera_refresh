# PRIMARY2.4 TC20NATIVE1A validation summary

## Purpose
Move the expensive frozen TC20 image-domain meter from Java into the already-working `m9color` native library without changing TC20's photographic decision.

This package is a direct derivative of device-validated PRIMARY2.3 JNI1 FIX7. It intentionally does **not** implement quickselect/weighted selection yet. The frozen full sort remains the algorithmic reference for the first native gate.

## Runtime architecture
The renderer still:

1. normalizes the full RAW and derives the accepted RAW-tail guard from per-CFA histograms;
2. performs OpenCV EA demosaic;
3. creates the exact 1600-long-side `INTER_AREA` meter image;
4. transfers that meter image once to a `short[]`;
5. calls one JNI TC20 meter function;
6. uses Java for the accepted TC20 gain/headroom decision;
7. reuses the same native context for the unchanged FIX7 full-colour strip renderer.

The native meter performs the previously Java-side expensive work:

- H25/HSM camera-to-profile processing;
- XYZ50 -> D65 -> linear-sRGB luma proxy;
- valid population (`Y > 1e-5`);
- full luma sort;
- Gaussian centre-weighted median;
- legacy P98 diagnostic.

The Java-side gain definition is still the FIX7 definition. The RAW-tail guard is untouched.

## Deliberately frozen
No changes were made to:

- R3.8 exposure allocation or LUMA2.4-SPATIAL2-FB1 feedback;
- 1600-side meter resize and `INTER_AREA` semantics;
- `METER_TARGET`, `METER_CW`, TC20 headroom target, RAW-tail quantiles or adaptive tail logic;
- H25/HSM strengths;
- M9 bridge;
- SAT3 M06/M07;
- curve02;
- exact BT.601 horizontal 4:2:2 pairing;
- TG1;
- full-colour 24-row/four-worker native strip scheduling;
- JPEG/DNG output ordering or DNG contents.

## Host validation
### Native C++ syntax
`m9color_jni.cpp` compiled successfully with host `g++` using the JNI headers and the package's production arithmetic flags:

`-O3 -ffp-contract=off -fno-fast-math`

### Existing full-colour parity
The pre-existing actual-C++ colour harness was rebuilt against the new native source. Hashes remain unchanged:

- case0 `d8a41181af097d65`
- case1 `4fa72399bad9d8bb`
- case2 `4186500ffb6b1f36`
- case3 `b9b94cc14c4f68ca`
- aggregate `7e21b6ae4a9557ae`

This confirms the context extension and TC20 addition did not change the promoted FIX7 colour kernel.

### TC20 Java-vs-JNI parity
`reference/Tc20Native1aParityTest.java` was compiled against the actual JNI implementation. On the deterministic synthetic test frame:

- Java weighted median: `0.46205609372066964`
- Native weighted median: `0.46205609372066964`
- Java P98: `0.82639677488795830`
- Native P98: `0.82639677488795830`
- valid population: `49082` on both paths

Result: **PASS**.

## New diagnostics
The renderer adds:

- `tc20MeterMode = native_scalar_fullsort_parity1a`
- `tc20NativeLibrary = m9color`
- `tc20Algorithm = frozen_full_sort_weighted_median`
- `tc20JavaGainMath = true`
- `meterResizeElapsedMs`
- `meterTransferElapsedMs`
- `nativeTc20ElapsedMs`

`meterTc20ElapsedMs` remains the wall-clock total for resize + transfer + native TC20 work.

## Device acceptance gate
This build is accepted only if:

1. app startup remains healthy (FIX7 native packaging regression stays solved);
2. JPEG and DNG both save normally;
3. `gain`, `baseMedianGain`, `legacyP98Proxy`, `tc20GuardGain` and visual rendering show no meaningful drift versus equivalent FIX7 captures;
4. `meterTc20ElapsedMs` falls materially below the FIX7 example (~786 ms);
5. no regression appears in full-colour timing.

Only after this gate should TC20NATIVE1B replace full sort with weighted selection/quickselect.
