# QUEUE1A validation summary

## Confirmed device failure

The rapid-shot failure is queue backpressure, not a new COLORNATIVE2A native crash. Device logcat shows the primary render queue reaching capacity and executing the old blocking path:

```text
PRIMARY2.2 queue full; waiting for a render slot
```

The old code caught `RejectedExecutionException` from the bounded `ThreadPoolExecutor` and then called:

```java
EXECUTOR.getQueue().put(job);
```

Because `DefaultSaver` cannot complete its processing-finished lifecycle until `enqueue()` returns, a full render queue could block Photon until a renderer slot became available. The same burst produced multi-second `queueWaitElapsedMs`, confirming that captures were outpacing the single JPEG+DNG worker.

## QUEUE1A change

QUEUE1A freezes the complete photographic renderer and changes only queue/backpressure behavior.

### Removed

```java
EXECUTOR.getQueue().put(job);
```

There is no blocking queue wait fallback on the Photon saver/capture path.

### New enqueue contract

`M9PrimaryRenderQueue.enqueue(...)` now returns `boolean`.

- `true`: the bounded renderer queue accepted the frame and owns/closes it.
- `false`: the queue was saturated; ownership is not transferred and `DefaultSaver` closes the frame immediately after `enqueue()` returns.

`DefaultSaver` now assigns the actual return value:

```java
queued = M9PrimaryRenderQueue.enqueue(...);
if (queued) {
    primaryFrame = null;
}
```

This preserves prompt `onProcessingFinished(...)` execution even when the render queue is full.

## Saturation behavior

QUEUE1A intentionally keeps:

```text
workers: 1
MAX_PENDING: 2
maximum accepted in-flight renders: 3
```

A further frame is rejected immediately instead of blocking. It therefore will not produce JPEG or DNG in this diagnostic branch. Its already-frozen `_M9.json` is still scheduled for asynchronous persistence, and an asynchronous `_M9_PRIMARY.json` rejection sidecar is created.

This policy is deliberately conservative. The next decision after device validation is whether production behavior should increase bounded capacity, gate the shutter before capture, or use another nonblocking admission policy.

## New diagnostics

Timing schema:

```text
m9cam.primarytiming.v2.queue1a
```

Added:

```text
queueDepthAtEnqueue
activeRenderCountAtEnqueue
queueCapacity
queueFullCountAtEnqueue
enqueueWaitElapsedMs
queueAccepted
queueOutcome
```

Rejected frame signature:

```text
queueAccepted: false
queueOutcome: rejected_queue_full
jpegSaved: false
dngSaved: false
error: primary_queue_full_nonblocking_reject
```

## Frozen renderer

No photographic/render math changed. Retained exactly from v0.7ZD FIX1:

- R3.8 H25/TG1;
- Cobalt main calibration;
- M9 bridge;
- TC20NATIVE1B;
- SAT3 M06/M07;
- curve02;
- exact source-horizontal BT.601 4:2:2;
- LUMA2.4-SPATIAL2-FB1;
- ORIENT1A;
- NORMNATIVE1A;
- METAFREEZE1A;
- COLORNATIVE2A FIX1;
- 384-row native blocks;
- 8 native colour calls/frame at 4096x3072;
- 4 native workers per full block;
- JPEG-first / development-DNG-second worker order.

Renderer schema therefore stays frozen:

```text
m9cam.renderer.r38.h25tg1.full12.android.v19.primary2p4tc20native1borient1anormnative1acolornative2afix1
```

## Device gate

Take 5-6 shots rapidly enough to saturate the queue.

Pass requires:

- no `queue full; waiting for a render slot` line;
- no freeze requiring app restart;
- `enqueueWaitElapsedMs` remains near zero;
- accepted frames report `queueAccepted=true`;
- saturation, if reached, reports `queueAccepted=false` and `rejected_queue_full` rather than waiting;
- the camera remains usable and can take another frame after the worker drains;
- accepted frames continue to save JPEG+DNG and report `nativeColorCalls == 8`, `nativeColorWorkersUsed == 4`, `orientationElapsedMs == 0`.

## Build identity

```text
package:
M9Cam_v0_7ZE_QUEUE1A_COLORNATIVE2A_FIX1_TC20NATIVE1B_ORIENT1A_NORMNATIVE1A_METAFREEZE1A.zip

versionName:
1.20-m9modern7r38luma24fb1primary24tc20native1borient1anormnative1ametafreeze1acolornative2afix1queue1a

timing route:
M9-PRIMARY2.4-TC20NATIVE1B-ORIENT1A-NORMNATIVE1A-METAFREEZE1A-COLORNATIVE2A-FIX1-QUEUE1A
```
