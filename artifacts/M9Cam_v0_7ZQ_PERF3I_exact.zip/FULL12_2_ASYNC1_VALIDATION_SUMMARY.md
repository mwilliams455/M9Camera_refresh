# FULL12-2 ASYNC1 validation summary

Build target: `0.99-m9modern7r38luma24fb1full12async1`

## Purpose
Remove the ~7.5 s FULL12-1 JPEG renderer from Photon's capture-buffer critical section without changing any photographic decision or render constant.

## New lifecycle
`DNG save -> detached RAW copy -> capture JSON snapshot -> close original ImageFrame -> clear IMAGE_BUFFER -> bufferLock=false -> bounded background JPEG queue`

## Queue safety
- exactly one renderer worker
- at most two waiting detached RAW frames
- Android `THREAD_PRIORITY_BACKGROUND`
- saturation back-pressure occurs only after `bufferLock=false`
- detached frame closed by queue worker

## Diagnostic race protection
`_M9.json` is written while live analyzer state still belongs to that capture. Its renderer section reports `status=queued`; the entire capture JSON is not rewritten after later captures can alter global analyzer snapshots.

## Frozen invariants
H25/S85/V100, TC20, SAT3 M06/M07, curve02, exact BT.601 4:2:2, TG1, LUMA2.4-SPATIAL2, FB1 +0.75 EV ceiling, M9Modern v0.6.1, 1600-side TC20 meter, 24-row renderer, JPEG quality 95.

## Device gate
1. DNG/JSON save.
2. Shutter becomes available before first 12 MP JPEG finishes.
3. First JPEG later appears at native resolution.
4. A second quick capture also produces DNG/JSON/JPEG.
5. No OOM/app death.
6. Exposure/FB1 data remains capture-specific.
7. JPEG appearance matches FULL12-1.

## Packaging validation performed

- patch/verifier Python syntax: PASS
- serial background queue Java compile smoke with Android/Photon stubs: PASS
- capture lifecycle ordering assertions: PASS
  - DNG save before detach
  - detach before capture JSON
  - capture JSON before buffer release
  - `bufferLock=false` before renderer enqueue
  - no synchronous `renderAndSave` call in M9 DefaultSaver route
- background diagnostics race guard: PASS (`renderAndSave` does not overwrite capture-time `lastDiagnostics`)
- FULL12 streamed SAT3/curve02/BT.601/TG1 arithmetic regression: PASS
- frozen H25/TG1/TC20/FB1 constants audit: PASS

Android/GitHub remains the actual full compile gate.


## FIX1 — workflow self-check correction

The first ASYNC1 package had one stale apply-script self-check that still required
`M9R35Renderer.renderAndSave` inside `DefaultSaver.java`. ASYNC1 intentionally removes
that synchronous call and replaces it with `detachForBackground` +
`M9BackgroundRenderQueue.enqueue`. The self-check is now aligned with the actual async
architecture. No Java payload, photographic constants, renderer math, FB1 behavior, or
build identity changed.
