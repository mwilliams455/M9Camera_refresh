# TIMINGFREEZE1A validation summary

## Direct base

`v0.7ZF NAME1A + QUEUE1B COLORNATIVE2A FIX1 TC20NATIVE1B ORIENT1A NORMNATIVE1A METAFREEZE1A`

## Why this build exists

Device validation promoted NAME1A and QUEUE1B, but correlation of logcat with `_M9_PRIMARY.json`
showed the single `M9PrimaryRenderer` worker could remain occupied for roughly another couple of
seconds after JPEG+DNG work had completed. The synchronous `_M9_PRIMARY.json` SAF write happened
inside the render worker's `finally` block, while `workerElapsedMs` was measured before that write.
This both extended queue occupancy and under-reported the true worker lifetime.

## TIMINGFREEZE1A change

Accepted primary timing now follows a freeze/defer model:

1. Build the complete timing object on `M9PrimaryRenderer` after JPEG+DNG completion.
2. Deep-copy renderer diagnostics and serialize the complete sidecar to immutable UTF-8 bytes.
3. Enqueue only `(timingPath, byte[])` onto dedicated daemon thread `M9PrimaryTimingIO`.
4. Immediately close the owned `ImageFrame` and decrement QUEUE1B in-flight accounting.
5. SAF persistence happens on `M9PrimaryTimingIO`, never on `M9PrimaryRenderer`.

No RAW frame, `M9R35Renderer.Result`, capture result, or mutable `JSONObject` is retained by the
asynchronous timing writer.

QUEUE1B fallback rejection timing remains asynchronous and uses the same isolated timing I/O
executor. METAFREEZE1A capture-metadata persistence remains unchanged.

## Timing schema

Accepted and fallback primary timing sidecars now identify:

`m9cam.primarytiming.v4.timingfreeze1a`

New fields include:

- `primaryTimingMode = frozen_bytes_deferred_persist_after_worker`
- `primaryTimingFrozenBeforeFrameRelease`
- `primaryTimingIoOffRenderWorker = true`
- `primaryTimingFreezeElapsedMs`
- `primaryTimingProvisionalBytes`
- `workerElapsedBoundary = before_primary_timing_freeze`

Logcat additionally records the actual render-worker release time as
`QUEUE1B TIMINGFREEZE1A worker released ...` so device validation can compare queue drain directly.

## Frozen behavior

No photographic/render math changed. The following payloads are byte-for-byte unchanged from
v0.7ZF:

- `M9R35Renderer.java`
- `M9NativeColorCore.java`
- `m9color_jni.cpp`
- calibration asset/manifest
- `M9SubjectMotionAnalyzer.java`
- `M9DeferredMetadataStore.java`
- `M9CapturePathAllocator.java`

Renderer schema remains:

`m9cam.renderer.r38.h25tg1.full12.android.v19.primary2p4tc20native1borient1anormnative1acolornative2afix1`

NAME1A, QUEUE1B, METAFREEZE1A, COLORNATIVE2A FIX1, TC20NATIVE1B, ORIENT1A,
NORMNATIVE1A, H25/HSM, SAT3, curve02, BT.601/TG1 and LUMA2.4-SPATIAL2-FB1 are retained.

## Host/static validation

- patch script `py_compile`: PASS
- verifier `py_compile`: PASS
- TIMINGFREEZE1A source guard: PASS
- queue/timing Java syntax with Android/Photon stubs: PASS
- injected 2000 ms timing-storage stall: `freezeAndWriteAsync()` returned in 67 ms on the final host rerun: PASS
- `MAX_PENDING = 2`: PASS
- QUEUE1B preflight and nonblocking fallback retained: PASS
- accepted timing freeze occurs before `ownedFrame.close()`: PASS
- synchronous `M9PrimaryTimingWriter.write(...)` absent from render worker: PASS
- renderer/native source hashes unchanged from v0.7ZF: PASS

## Device gate

Run the same rapid-shot saturation test and upload logcat plus several `_M9_PRIMARY.json` files.
Expected:

- schema `m9cam.primarytiming.v4.timingfreeze1a`
- `primaryTimingIoOffRenderWorker=true`
- `primaryTimingFrozenBeforeFrameRelease=true` for accepted jobs
- timing persistence logs may still take seconds, but occur on `M9PrimaryTimingIO`
- `QUEUE1B TIMINGFREEZE1A worker released` should occur immediately after photographic + DNG work
- the next queued `starting PRIMARY2.4` should follow worker release without waiting for timing SAF I/O
- queue waits should converge toward actual JPEG+DNG worker throughput rather than diagnostic storage latency
