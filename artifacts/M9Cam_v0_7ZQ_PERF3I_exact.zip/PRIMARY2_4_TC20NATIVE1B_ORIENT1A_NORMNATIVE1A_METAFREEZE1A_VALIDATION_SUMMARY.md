# PRIMARY2.4 TC20NATIVE1B ORIENT1A NORMNATIVE1A METAFREEZE1A validation summary

## 1. Incoming device result: NORMNATIVE1A passes decisively

Two Xiaomi 15 Ultra main-camera frames were returned from v0.7ZB.

### IMG_20260901_073107

```text
captureMetadataElapsedMs             1793
renderElapsedMs                       820
renderCoreElapsedMs                   550
normalizeRawElapsedMs                  31
nativeNormalizeRawElapsedMs            22
nativeNormalizeComputeElapsedMs        12
nativeNormalizeOutputCopyElapsedMs     10
nativeNormalizeWorkersUsed              4
demosaicElapsedMs                      22
meterTc20ElapsedMs                    195
nativeTc20ElapsedMs                   166
fullColorRenderElapsedMs              297
directOrientedCommitElapsedMs          36
orientationElapsedMs                    0
jpegEncodeWriteElapsedMs              239
dngSaveElapsedMs                      559
workerElapsedMs                      1382
```

### IMG_20260901_073111

```text
captureMetadataElapsedMs             2087
renderElapsedMs                       964
renderCoreElapsedMs                   667
normalizeRawElapsedMs                  42
nativeNormalizeRawElapsedMs            28
nativeNormalizeComputeElapsedMs        17
nativeNormalizeOutputCopyElapsedMs     10
nativeNormalizeWorkersUsed              4
demosaicElapsedMs                      29
meterTc20ElapsedMs                    230
nativeTc20ElapsedMs                   197
fullColorRenderElapsedMs              361
directOrientedCommitElapsedMs          31
orientationElapsedMs                    0
jpegEncodeWriteElapsedMs              265
dngSaveElapsedMs                      604
workerElapsedMs                      1571
```

Incoming ORIENT1A Java-normalization references were:

```text
311 ms
534 ms
```

NORMNATIVE1A therefore reduced the high-level normalization stage to:

```text
31 ms
42 ms
```

This is approximately a 90%+ reduction in both representative cases. Native compute itself is only 12-17 ms; the fixed output array copy is 10 ms.

Decision:

```text
NORMNATIVE1A = PROMOTED
```

The visual outputs remain correctly oriented and show no obvious renderer corruption. `orientationElapsedMs` remains zero.

## 2. New bottleneck

With render now approximately 0.82-0.96 s, the synchronous capture metadata path is larger than the renderer:

```text
captureMetadataElapsedMs = 1793 / 2087 ms
renderElapsedMs          =  820 /  964 ms
```

This metadata path still executes before `bufferLock = false`, so it directly delays capture release / shot-to-shot responsiveness.

The existing writer constructs the diagnostic JSON and then synchronously opens/writes/flushes `_M9.json` using Photon/Android storage. The latest sidecars are only roughly 25-26 KiB, making storage/SAF setup a strong candidate for the large delay.

## 3. METAFREEZE1A design

Freeze semantics, defer persistence.

Capture critical section:

```text
current capture state
  -> raw/capture/request/sensor JSON
  -> Photon exposure decision
  -> motion + preview-luma/spatial snapshots
  -> m9Renderer queued diagnostics
  -> m9Build
  -> m9ExposureFeedback
  -> m9BacklightDiagnostic
  -> root.toString(2)
  -> UTF-8 byte[]
  -> in-memory stage
  -> release bufferLock
```

Deferred path:

```text
primary M9 JPEG
  -> development DNG
  -> schedule frozen _M9.json byte[]
  -> dedicated background persistence thread
```

No capture-specific object is re-read after buffer release. The bytes written later are the exact bytes serialized before release.

## 4. Files changed from v0.7ZB

New:

```text
app/src/main/java/com/particlesdevs/photoncamera/m9/M9DeferredMetadataStore.java
```

Changed only for persistence scheduling/timing identity:

```text
M9PrimaryRenderQueue.java
M9PrimaryTimingWriter.java
M9CaptureMetadataWriter.java   (patched in target tree)
M9BacklightDiagnostic.java     (build-version string only)
app/build.gradle               (version only)
```

Frozen renderer files are byte-identical to v0.7ZB:

```text
M9R35Renderer.java
SHA-256 b562afb35d7dd304a6e582af64607186da1f1a1710683f0cc829261b07564a81

M9NativeColorCore.java
SHA-256 8b8655df5490497bc7674d002f168b20a41184391c8c2a3474cf33b02e1373d6

m9color_jni.cpp
SHA-256 a5713aeb520114d9da6cbeb3943d897a03aa5cfff2bfb1b8066a2be0a9d8d99a

m9_r35_calibration.bin
SHA-256 5568978ea42e7c65b51f26ffc2d56479418ec6c8d98b242199bab08acb62cbca
```

The only `M9BacklightDiagnostic.java` difference is the build identity string from 1.16 to 1.17; classifier constants/math are unchanged.

## 5. New primary timing audit fields

```text
route
  M9-PRIMARY2.4-TC20NATIVE1B-ORIENT1A-NORMNATIVE1A-METAFREEZE1A

captureMetadataMode
  frozen_bytes_deferred_persist_after_dng

captureMetadataPersistScheduled
  true / false
```

`captureMetadataElapsedMs` now intentionally means:

```text
snapshot + serialize + in-memory stage
```

and excludes `_M9.json` storage persistence.

## 6. Static / host validation

Passed:

```text
Python patch/verifier py_compile
metadata persistence-block regex smoke
changed Java source host syntax compile with Android/Photon stubs
renderer/native/calibration byte-freeze comparison against v0.7ZB
ORIENT1A 0/90/180/270 exact mapping regression
LUMA2.4 exact-field regression
LUMA2.4 FB1 energy arithmetic regression
```

Inherited parity evidence retained:

```text
NORMNATIVE1A actual JNI checksum exact
TC20NATIVE1B Java/JNI weighted-selection exact
```

Android/GitHub build and device execution remain the final platform gate.

## 7. Device acceptance gate

Take 2-3 ordinary frames, preferably at least one landscape and one portrait.

Upload:

```text
JPEG
*_M9_PRIMARY.json
*_M9.json
```

DNG is optional for this particular performance gate.

Required checks:

```text
JPEG saved
DNG saved
_M9.json eventually appears
captureMetadataPersistScheduled == true
orientationElapsedMs == 0
no visual regression
```

Primary performance target:

```text
old captureMetadataElapsedMs:
1793 ms
2087 ms

METAFREEZE1A:
<= 300 ms  strong PASS
<= 100 ms  excellent PASS
```

If it remains above ~1 s, do not remove diagnostics blindly. Instrument the synchronous snapshot/serialization subcomponents next to identify the remaining cost.

## 8. Build identity

```text
package:
M9Cam_v0_7ZC_TC20NATIVE1B_ORIENT1A_NORMNATIVE1A_METAFREEZE1A.zip

versionName:
1.17-m9modern7r38luma24fb1primary24tc20native1borient1anormnative1ametafreeze1a

renderer schema (unchanged):
m9cam.renderer.r38.h25tg1.full12.android.v17.primary2p4tc20native1borient1anormnative1a

primary timing route:
M9-PRIMARY2.4-TC20NATIVE1B-ORIENT1A-NORMNATIVE1A-METAFREEZE1A
```
## Packaging FIX1 note

The first METAFREEZE1A archive contained a verifier-only runtime typo at `verify-m9cam-v0.7-r35.py:148`: it called `read(deferred_rel)` although this verifier defines the file loader as `load()`. FIX1 changes that single call to `load(deferred_rel)`. No application source or photographic/performance logic changed.


