# COLORNATIVE2A validation summary

## Incoming ZC device baseline

The two 2026-09-01 METAFREEZE1A frames establish the immediate baseline:

| Metric | 080938 landscape | 080932 portrait |
|---|---:|---:|
| captureMetadataElapsedMs | 20 | 29 |
| queueWaitElapsedMs | 0 | 0 |
| renderElapsedMs | 692 | 801 |
| renderCoreElapsedMs | 519 | 600 |
| normalizeRawElapsedMs | 37 | 59 |
| meterTc20ElapsedMs | 131 | 135 |
| fullColorRenderElapsedMs | 317 | 371 |
| directOrientedCommitElapsedMs | 27 | 54 |
| orientationElapsedMs | 0 | 0 |
| jpegEncodeWriteElapsedMs | 138 | 159 |
| dngSaveElapsedMs | 404 | 420 |
| workerElapsedMs | 1098 | 1224 |

METAFREEZE1A therefore passes and is treated as promoted. The remaining renderer bottleneck is the scalar full-colour stage.

## Previous colour scheduling boundary

At 4096x3072, the promoted implementation used:

```text
RENDER_STRIP_ROWS = 24
3072 / 24 = 128 JNI colour calls
4 Java executor workers
```

Each JNI call performs GC-safe Java-to-native and native-to-Java array-region copies around the frozen scalar kernel. The two device frames recorded native task sums of roughly 927 ms and 1011 ms against wall full-colour times of 317 ms and 371 ms.

## COLORNATIVE2A design

A literal one-call/full-frame Java bridge was rejected for this experiment because it would require approximately 75.5 MB RGB16 input + 50.3 MB ARGB output before GC-safe native scratch is counted.

COLORNATIVE2A uses:

```text
NATIVE_COLOR_BLOCK_ROWS = 384
NATIVE_COLOR_WORKERS = up to 4
4096x3072 main frame => 8 JNI calls
```

Inside each JNI call, native code divides the block into disjoint contiguous row ranges and calls the existing `renderStripScalar` kernel directly. There is no SIMD, no fast-math, no kernel rewrite and no reordering of horizontal BT.601 pairs.

## Correctness evidence

Host tests passed:

```text
COLORNATIVE2A row-partition scalar parity PASS
COLORNATIVE2A 0/90/180/270 block orientation parity PASS
```

The row-partition test includes the production `m9color_jni.cpp` translation unit and compares full sequential output/diagnostics with 1, 2, 3, 4 and 7-way disjoint-row execution. ARGB output and the even/edge/near-white counters are exact.

The orientation test validates 384-row block commits against direct full-frame 0/90/180/270 rotation at 4096x3072 and at non-divisible synthetic dimensions.

C++ syntax compile also passes with the production scalar floating-point constraints:

```text
-ffp-contract=off
-fno-fast-math
```

## Device acceptance fields

Expected final renderer diagnostics on Xiaomi 15 Ultra main:

```text
nativeColorBlockRows = 384
parallelColorWorkers = 4
parallelColorMode = native_block_internal_threads_scalar_math
nativeColorMode = scalar_cpp_jni_blockthreads2a
nativeColorCalls = 8
nativeColorWorkersUsed = 4
nativeColorVectorization = disabled_scalar_baseline
orientationElapsedMs = 0
```

Additional timing:

```text
nativeColorTaskElapsedMsSum
nativeColorJniElapsedMsSum
fullColorRenderElapsedMs
directOrientedCommitElapsedMs
```

## Performance decision

Compare directly with the incoming ZC full-colour measurements:

```text
317 ms
371 ms
```

Promotion requires no visual/orientation regression and a repeatable timing improvement. A result around or below roughly 280-320 ms is useful. A repeatable regression above 400 ms means block-local native thread creation/copy cost outweighs the reduced JNI scheduling overhead and COLORNATIVE2A should be rejected or retuned rather than promoted.

## Rapid-shot gate

After the landscape/portrait pair, capture 3-4 frames as rapidly as Photon permits. The important fields are:

```text
queueWaitElapsedMs
renderElapsedMs
workerElapsedMs
dngSaveElapsedMs
captureMetadataElapsedMs
```

This will establish whether the background worker, particularly the 400+ ms DNG persistence, can accumulate queue pressure even though capture metadata is no longer synchronous.

## Build identity

```text
versionName:
1.19-m9modern7r38luma24fb1primary24tc20native1borient1anormnative1ametafreeze1acolornative2afix1

renderer schema:
m9cam.renderer.r38.h25tg1.full12.android.v19.primary2p4tc20native1borient1anormnative1acolornative2afix1

primary timing route:
M9-PRIMARY2.4-TC20NATIVE1B-ORIENT1A-NORMNATIVE1A-METAFREEZE1A-COLORNATIVE2A-FIX1
```

Android/GitHub compilation and actual device timing remain the final platform gate.
