# PRIMARY2.3 JNI1 FIX2 validation summary

Date: 2026-08-31


## Reason for FIX2

FIX1 correctly stopped replacing PhotonCamera's CMake project, but its patch guard still assumed a particular upstream native source layout (`dngCreator.cpp`, `allocator.cpp`, `flacRecorder.cpp`, `native-engine.cpp`). The active GitHub checkout rejected that assumption before CMake was modified. FIX2 removes all upstream target/source-name assumptions. It requires only a non-empty `app/src/main/cpp/CMakeLists.txt`, preserves it, and appends the isolated `m9color` target.

## Reason for FIX1

The first PRIMARY2.3 JNI1 package could build successfully but the resulting PhotonCamera APK could fail immediately at launch.

Root cause was native-build integration, not the scalar colour kernel.

PhotonCamera already owns:

```text
app/src/main/cpp/CMakeLists.txt
```

and that project defines launch/runtime native targets including:

```text
ncnnMl
dngCreator
allocator
flacRecorder
camera2native
```

The first JNI1 package incorrectly shipped its own replacement `CMakeLists.txt` containing only `m9color`. Because `app/build.gradle` already points at `src/main/cpp/CMakeLists.txt`, replacing that file removed PhotonCamera's original native targets while still allowing Gradle/CMake to produce an APK.

That explains the observed pattern:

```text
GitHub build: PASS
APK install: possible
App launch: FAIL
```

FIX1 changes the integration from replacement to additive.

## FIX1 native-build model

The package no longer contains:

```text
payload/app/src/main/cpp/CMakeLists.txt
```

Instead, the patch script first verifies the existing PhotonCamera CMake project still contains:

```text
dngCreator.cpp
allocator.cpp
flacRecorder.cpp
native-engine.cpp
```

and then appends only:

```cmake
add_library(m9color SHARED ${CMAKE_CURRENT_SOURCE_DIR}/m9color_jni.cpp)
set_target_properties(m9color PROPERTIES
    CXX_STANDARD 17
    CXX_STANDARD_REQUIRED ON
    CXX_EXTENSIONS OFF
)
target_compile_options(m9color PRIVATE -O3 -ffp-contract=off -fno-fast-math)
target_link_options(m9color PRIVATE -Wl,-z,max-page-size=16384)
```

Therefore PhotonCamera continues to own its native build and `m9color` becomes one additional target.

## Safer native loading

The first JNI1 bridge used an unconditional class initializer:

```java
static {
    System.loadLibrary("m9color");
}
```

FIX1 removes that startup-sensitive initializer.

Native loading is now lazy through:

```text
M9NativeColorCore.ensureLoaded()
```

immediately before the renderer creates the native colour context. A linker/load failure therefore cannot kill PhotonCamera simply because the bridge class is initialized.

The loader preserves the Java exception class/message in `loadError()` for renderer failure diagnostics.

## 16 KiB page compatibility

The `m9color` target is linked with:

```text
-Wl,-z,max-page-size=16384
```

This is compatible with the existing PhotonCamera native build direction and avoids leaving the new library dependent on 4 KiB ELF segment assumptions on newer Android devices.

## Photographic / performance scope

FIX1 does **not** alter the PRIMARY2.3 scalar-native colour algorithm.

Unchanged:

- 24-row strips
- four colour workers
- serialized OpenCV `Mat.get`
- ordered Bitmap commits
- H25/S85/V100
- Cobalt HSM calibration
- PRIMARY2.2 precomposed M9 bridge
- SAT3 M06/M07
- curve02
- exact horizontal BT.601 4:2:2 semantics
- TG1
- TC20
- LUMA2.4-SPATIAL2-FB1
- RAW normalization
- orientation
- JPEG quality
- scalar C++ only; no NEON yet

## Native parity re-check

The actual unchanged `m9color_jni.cpp` was compiled again on the host with:

```text
C++17
-O3
-ffp-contract=off
-fno-fast-math
```

Four gain/TG cases over a 257 x 97 odd-width strip produced:

```text
case0 hash=d8a41181af097d65 even=12148 edge=38679 nearWhite=3743
case1 hash=4fa72399bad9d8bb even=12669 edge=50029 nearWhite=7350
case2 hash=4186500ffb6b1f36 even=15143 edge=56958 nearWhite=10499
case3 hash=b9b94cc14c4f68ca even=16275 edge=59506 nearWhite=12253
aggregate=7e21b6ae4a9557ae
pixels=24929 x 4 = 99,716
```

This is the same aggregate fingerprint as the original JNI1 parity run.

## Build identity

```text
versionName:
1.07-m9modern7r38luma24fb1primary23jni1fix2

renderer schema:
m9cam.renderer.r38.h25tg1.full12.android.v10.primary2p3jni1fix2

route:
M9-PRIMARY2.3-JNI1-FIX2

nativeColorMode:
scalar_cpp_jni_parity1
```

## First device gate

First gate is now deliberately two-step:

```text
1. App launches normally and camera preview works.
2. Take two M9 frames and return both *_M9_PRIMARY.json files.
```

Expected renderer fields:

```text
route/resolutionMode     M9-PRIMARY2.3-JNI1-FIX2
nativeColorCore          true
nativeColorMode          scalar_cpp_jni_parity1
parallelColorWorkers     4
nativeColorCalls         approximately 128 for 3072 source rows
```

Primary performance comparison remains against the validated PRIMARY2.2 best colour result:

```text
fullColorRenderElapsedMs = 1675 ms
```

Interpretation:

```text
<= 1300 ms repeated    strong scalar-native pass
1300-1500 ms           useful pass
1500-1700 ms           modest gain
>= 1700 ms repeated    scalar C++ alone is insufficient; proceed to NEON / memory-layout work
```

Do not begin NEON until this FIX1 APK both launches and proves scalar device parity/timing.

## FIX2 packaging validation (2026-08-31)

Performed after the FIX2 patch change:

- patch/verifier Python syntax compilation: PASS
- payload contains no `CMakeLists.txt`: PASS
- patch/verifier contain no checks for upstream Photon native filenames: PASS
- layout-agnostic CMake append regression using an unrelated existing Photon target: PASS
- upstream CMake prefix preserved byte-for-byte by the append model: PASS
- append model is idempotent when `m9color` already exists: PASS
- `m9color_jni.cpp` host compile with `-O3 -ffp-contract=off -fno-fast-math`: PASS
- actual native parity harness vs Java PRIMARY2.2 oracle: PASS
- parity aggregate: `7e21b6ae4a9557ae`
- parity coverage: 24,929 pixels × 4 scenarios = 99,716 rendered pixels

FIX2 changes only the native-build integration guard/append seam and build identity. The scalar colour kernel remains unchanged.
