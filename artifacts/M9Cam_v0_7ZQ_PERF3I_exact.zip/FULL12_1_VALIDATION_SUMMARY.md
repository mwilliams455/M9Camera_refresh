# FULL12-1 validation summary

Build target: `0.98-m9modern7r38luma24fb1full12`

## Purpose

Native-resolution renderer promotion directly from field-tested v0.7N. Exposure feedback remains LUMA2.4-SPATIAL2-FB1 with the same thresholds, gates and +0.75 EV ceiling. R3.8 H25/TG1, TC20, SAT3 M06/M07, curve02, the exact BT.601 horizontal 4:2:2 stage and the Cobalt main-camera calibration are unchanged.

## Resolution architecture

- Xiaomi main RAW input: 4096x3072 (~12.6 MP)
- Final landscape JPEG: 4096x3072
- Final portrait JPEG after physical orientation: 3072x4096
- TC20 meter reference: still 1600-pixel long side via OpenCV INTER_AREA, exactly matching N's meter input resolution
- Final render: native resolution, streamed in 24-row strips
- Temporary `_M9_PARITY.png`: disabled
- Untouched DNG save: retained
- `_M9.jpg`: retained
- `_M9.json`: retained as diagnostic sidecar

## Why streaming is required

A naive `LONG_SIDE=4096` change to N would retain full-resolution `double[] m9`, `double[] ylin`, RGB8 and ARGB intermediates and could consume several hundred MB in addition to OpenCV's full-size demosaic Mat. FULL12-1 instead keeps only the OpenCV camera-space Mat, small meter-resolution arrays, a 24-row render strip and the destination Bitmap.

## Photographic invariants

No changes to:

- H25 / S85 / V100
- M9 camera-space bridge
- TC20 constants or logic
- SAT3 M06/M07 matrices
- curve02
- BT.601 coefficients / horizontal 4:2:2 chroma sharing
- TG1 thresholds or chroma compression
- LUMA2.4-SPATIAL2 thresholds
- FB1 eligibility / ordering / +0.75 EV cap
- M9Modern v0.6.1 motion policy

The 1600-side meter reference is deliberately preserved so TC20 gain selection remains anchored to N even though final pixels are rendered at native resolution.

## Validation in this package

- Python patch/verifier syntax: PASS
- FULL12 semantic invariants: PASS
- buffered-vs-streaming SAT3/curve02/BT.601/TG1 arithmetic regression: PASS (reference script)
- Java source brace/parenthesis structural smoke: PASS

A full Android/Gradle APK build is not available in this packaging environment. GitHub remains the compile/install gate. First-device validation should check output dimensions, JSON renderer schema, render time, JPEG write time, memory stability and a matched-downsample comparison against N.
