# PRIMARY2.3 JNI1 FIX6 validation summary

Date: 2026-08-31

## Reason for FIX6

FIX2 correctly stopped assuming PhotonCamera native source filenames, but its CMake patch and its self-check had an inconsistent idempotency contract. The patch skipped appending a second `m9color` target when `m9color` was already present, while the self-check still required the literal comment `# M9 PRIMARY2.3 JNI1 FIX2 additive native colour target`. On a checkout that already contained the valid target without that exact comment, the patch therefore applied successfully and then rejected its own result.

FIX6 removes comment/history dependence entirely. CMake validation is semantic.

## FIX6 CMake behaviour

- Requires only a non-empty upstream `app/src/main/cpp/CMakeLists.txt`.
- Does not ship a replacement CMake file.
- Does not assume any Photon target/source filenames.
- Detects `add_library(m9color ...)` with whitespace/multiline-tolerant regex.
- If `m9color` already exists and references `m9color_jni.cpp`, it is accepted without requiring any marker comment.
- If that valid target lacks scalar parity flags or 16 KiB alignment, FIX6 appends only the missing target properties.
- If `m9color` exists but points at another source, FIX6 refuses a target-name collision instead of silently hijacking it.
- A fresh upstream CMake receives exactly one additive `m9color` target.
- Re-running FIX6 is idempotent and does not create duplicate `add_library(m9color ...)` commands.

The patch self-check and standalone verifier now validate the real target (`m9color` + `m9color_jni.cpp`), scalar compile flags, and 16 KiB linker alignment. No comment marker is required.

## Additional verifier correction

During the FIX6 audit, the build-identity fields in the packaged `M9BacklightDiagnostic.java` were also brought into line with the current branch. This prevents a later semantic-verifier failure after the CMake self-check passes.

## Build identity

```text
versionName: 1.11-m9modern7r38luma24fb1primary23jni1fix6
renderer schema: m9cam.renderer.r38.h25tg1.full12.android.v14.primary2p3jni1fix6
route: M9-PRIMARY2.3-JNI1-FIX6
nativeColorMode: scalar_cpp_jni_parity1
```

## Photographic scope

No renderer mathematics were changed. The native kernel remains the scalar PRIMARY2.2 parity implementation: H25/HSM, precomposed M9 bridge, SAT3 M06/M07, curve02, exact horizontal BT.601 4:2:2 and TG1 remain frozen. Four colour workers and 24-row strips remain frozen. No NEON or fast-math is enabled.

## Validation

- patch/verifier Python syntax: PASS
- FIX6 CMake idempotency regression: PASS
- pre-existing markerless valid `m9color` target: PASS and preserved unchanged
- fresh opaque upstream CMake: PASS; one target appended
- multiline/whitespace existing target: PASS; missing properties self-healed
- unrelated `m9color` target collision: PASS; explicitly refused
- duplicate `m9color` target after repeated application: zero duplicates
- package payload contains no `CMakeLists.txt`: PASS
- scalar native source guard: PASS
- scalar C++ host parity fingerprint: `7e21b6ae4a9557ae` over 99,716 rendered pixels (unchanged from JNI1/FIX1/FIX2)

## Device gate

First confirm the GitHub patch/self-check completes and the APK builds. Then confirm PhotonCamera launches and preview works. After that, capture two frames and return both `_M9_PRIMARY.json` files for the scalar JNI timing decision.
