# v0.7K LUMA2.2 diagnostic scorer — independent-field replay

LUMA2.2 is a narrow diagnostic-only derivative of v0.7J LUMA2.1. It was added
after two independent outdoor frames exposed opposite failure modes:

- `182446`: a cloudy/high-contrast outdoor control that LUMA2.1 falsely scored
  at +0.75 EV.
- `182457`: a catastrophically underexposed preview whose entire luminance
  distribution collapsed so far that LUMA2.1 lost the relative-highlight
  structure and returned 0 EV.

No exposure feedback is enabled in v0.7K:

```text
appliedExposureCorrectionEv = 0.0
feedbackEnabled = false
exposureFeedbackEnabled = false
```

## Protection A — center-body protection

The existing LUMA2.1 branch is preserved, then attenuated only when the center
of the scene is substantially brighter than the global body:

```text
centerBodyProtectionScore = smoothstep(centerMinusGlobal, 16, 28)
centerBodyProtectionMultiplier = 1 - centerBodyProtectionScore

protectedRelativeScore =
    LUMA2.1_backlightStarvationScore
    * centerBodyProtectionMultiplier
```

This is deliberately a high-threshold protection. The new false positive
`182446` has `centerMedianMinusGlobalMedian = +26`, while the independently
replayed severe positives are -28, -16, -20 and +1.

## Protection B — catastrophic preview-collapse branch

A separate branch handles the case where AE spends exceptionally little
exposure energy and the whole preview becomes dark enough that no normal
relative highlight population survives:

```text
catastrophicEnergyScore =
    1 - smoothstep(energy, 0.03, 0.12 ISO*s)

catastrophicMedianDarkScore =
    1 - smoothstep(globalMedian, 32, 64)

catastrophicQ95DarkScore =
    1 - smoothstep(globalQ95, 64, 96)

catastrophicQ99DarkScore =
    1 - smoothstep(globalQ99, 80, 112)

previewCollapseScore =
    cbrt(
        catastrophicMedianDarkScore
        * catastrophicQ95DarkScore
        * catastrophicQ99DarkScore
    )

catastrophicAeStarvationScore =
    catastrophicEnergyScore * previewCollapseScore
```

The final LUMA2.2 decision score is:

```text
backlightStarvationScore = max(
    protectedRelativeBacklightStarvationScore,
    catastrophicAeStarvationScore
)
```

The existing `wouldApply >= 0.50`, recommendation ramp `0.35 -> 0.85`, and
maximum +0.75 EV are unchanged.

## Exact replay on the eight independent v0.7J captures available locally

| Frame | Class | J EV | K EV | center ΔY | center protection | catastrophic score | K result |
|---|---|---:|---:|---:|---:|---:|---|
| 180145 | strong backlight / high energy | 0.000 | 0.000 | -4 | 0.000 | 0.000 | retained control |
| 180202 | severe starved backlight | 0.750 | 0.750 | -28 | 0.000 | 0.000 | retained positive |
| 180216 | coloured/translucent backlight | 0.419 | 0.419 | -16 | 0.000 | 0.000 | retained graded positive |
| 180236 | moderate starved backlight | 0.547 | 0.547 | -20 | 0.000 | 0.000 | retained graded positive |
| 180311 | severe starved backlight | 0.750 | 0.750 | +1 | 0.000 | 0.000 | retained positive |
| 181706 | normal indoor/high contrast | 0.000 | 0.000 | -22 | 0.000 | 0.000 | retained control |
| 182446 | cloudy outdoor/high contrast false positive | 0.750 | **0.000** | +26 | **0.926** | 0.000 | corrected |
| 182457 | catastrophic/global AE starvation | 0.000 | **0.750** | +1 | 0.000 | **1.000** | newly detected |

For `182446`, the old relative score remains 1.0, but the +26 Y center/global
delta produces a center-protection score of ~0.926 and reduces the protected
relative score to ~0.074, below the EV recommendation ramp.

For `182457`, the old relative score remains 0 because the preview has no
bright population or q95 separation. The catastrophic branch instead sees:

```text
energy = 0.0125 ISO*s
median = 23
q95    = 46
q99    = 52
```

and scores 1.0.

## Older-bank guard checks

The pre-existing 21-frame LUMA2.1 regression remains preserved in
`LUMA2_1_VALIDATION_SUMMARY.md` as lineage evidence. Available historical
preview records also place known severe positives well below the new center
protection ramp (for example `171822` at -24 Y and `154013` at +3 Y), while the
old cloudy controls have healthy median/q95/q99 distributions and therefore do
not satisfy the catastrophic-collapse conjunction.

This is sufficient to build another diagnostic field candidate. It is **not**
a basis to enable capture-side feedback yet; v0.7K must be challenged with new
independent scenes first.
