# NAME1A + QUEUE1B validation summary

## Direct base

`v0.7ZE QUEUE1A FIX1 COLORNATIVE2A FIX1 TC20NATIVE1B ORIENT1A NORMNATIVE1A METAFREEZE1A`

## Why this build exists

QUEUE1A device testing established that queue saturation no longer blocks Photon. The burst log
also showed same-second capture-stem reuse and confirmed that QUEUE1A's safe rejection happens only
after a RAW has already been acquired.

## NAME1A

- Adds `M9CapturePathAllocator`.
- `DefaultSaver` now wraps `ImagePath.newDNGFilePath()` with the allocator before metadata/render work.
- Appends epoch milliseconds plus a same-millisecond sequence to the base stem.
- Performs no filesystem/SAF existence probe.
- The resulting DNG Path remains the single source for JPEG, `_M9.json`, and `_M9_PRIMARY.json` names.
- Host stress test generated 10,000 names from one identical second-resolution base path with zero collisions.

## QUEUE1B

- Adds an M9-only admission check in `CameraUIController.onTimerFinished()` immediately before
  `CaptureController.takePicture()`.
- Adds explicit `IN_FLIGHT_COUNT` and `MAX_IN_FLIGHT = 1 + MAX_PENDING` queue accounting.
- When three M9 renders are already in flight, the shutter attempt is refused before RAW capture and
  a short snackbar is shown.
- Admission is deliberately non-reserving to avoid leaking capacity if Camera2 fails before DefaultSaver.
- QUEUE1A executor-level `RejectedExecutionException` handling remains as the nonblocking safety net.
- `MAX_PENDING = 2` remains unchanged.
- `getQueue().put(job)` remains absent.

## Diagnostics

Timing schema is now:

`m9cam.primarytiming.v3.queue1b`

New identity fields include:
- `shutterAdmissionPolicy`
- `fallbackQueueRejectEnabled`
- `admissionRejectCountSnapshot`
- `captureStemPolicy`

Shutter-side refusals do not create a sidecar because no capture/path exists yet; they are logged.

## Frozen behavior

No photographic/render math changed. Renderer schema remains:

`m9cam.renderer.r38.h25tg1.full12.android.v19.primary2p4tc20native1borient1anormnative1acolornative2afix1`

TC20NATIVE1B, ORIENT1A, NORMNATIVE1A, METAFREEZE1A, COLORNATIVE2A FIX1,
H25/HSM, SAT3, curve02, BT.601/TG1 and LUMA2.4-SPATIAL2-FB1 are retained.

## Host/static validation

- patch script `py_compile`: PASS
- verifier `py_compile`: PASS
- NAME1A pure-Java 10,000-allocation uniqueness test: PASS
- unique-stem propagation seam in DefaultSaver: PASS
- QUEUE1B preflight-before-`takePicture()` seam: PASS
- M9-only admission guard: PASS
- explicit in-flight accounting: PASS
- `MAX_PENDING = 2`: PASS
- executor fallback rejection: PASS
- `getQueue().put(job)` absent: PASS

## Device gate

Rapidly shoot through saturation. Expected result: the first three in-flight jobs are accepted;
a further UI shutter attempt is refused before Camera2 capture, and capture works again as soon as
an in-flight render completes. Same-second accepted shots must have distinct stems across all four
M9 output files. Upload logcat and the resulting `_M9.json` / `_M9_PRIMARY.json` files.
