# PERF3G ORIENTFUSE8A Validation Summary

**Candidate:** `v0.7ZO / PRIMARY2.5 / PERF3G ORIENTFUSE8A`  
**Base:** device-validated `v0.7ZN / PERF3F EXIFASYNC1A`, itself direct from promoted PERF3E  
**Status:** DEVICE-VALIDATED / PROMOTED

## Purpose

Remove the remaining serial native completed-ARGB orientation copy from the full-color critical path without changing photographic math, source-horizontal BT.601 pairing, output pixels, JPEG encoder/quality, exposure, queue policy, or DNG ownership.

PERF3F device data showed a 24–31 ms native orientation copy per 12 MP frame while the eight COLOR8A workers had already completed their exact scalar pixel math. PERF3G moves each worker's already-completed ARGB source-row range through the exact ORIENT1A destination mapping before that worker exits.

## Frozen quality/photographic gates

Unchanged:

- 12 MP output (`4096x3072` pre-orientation, `3072x4096` at 90°)
- `jpegQuality = 95`
- Android `Bitmap.compress(JPEG, quality=95)` encoder
- JPEGBUF64K1A 64 KiB transport buffering
- PERF3F EXIFASYNC1A finalizer/publication ordering
- DNGASYNC1A ownership/preservation architecture
- TC20LUMA8A
- COLOR8A worker count = 8
- R3.8 H25/TG1
- Cobalt main calibration
- M9 bridge
- SAT3 M06/M07
- curve02
- exact firmware-style BT.601 horizontal 4:2:2
- exposure policy

No `-ffast-math`, NEON, approximation, resolution reduction, JPEG quality reduction, or encoder replacement.

## Exact execution change

PERF3F block path:

```text
8 COLOR workers render exact scalar source-order ARGB
-> join
-> serial orientCompletedStrip() over full 384-row block
-> JNI SetIntArrayRegion
-> Bitmap.setPixels
```

PERF3G block path:

```text
8 COLOR workers render exact scalar source-order ARGB
-> each worker immediately applies exact ORIENT1A mapping
   to its own disjoint source-row range
-> join
-> JNI SetIntArrayRegion
-> Bitmap.setPixels
```

For rotations 0/90/180/270, worker source-row partitions map to disjoint destination regions. No worker changes another worker's completed pixel and no source-horizontal pair arithmetic is moved or reordered.

The legacy `orientCompletedStrip()` function is retained byte-for-byte and remains used by the older `renderStrip` JNI path. PERF3G changes only `renderBlockParallel` execution.

## Frozen native kernel hashes

All quality-critical frozen functions remain unchanged:

```text
applyHsm
7f4e1e8224d976b65be68ae21fe5fcd3d5ef43d461507ea33f87c2007fffbe5a

cameraToSrgbLuma
d2247d137a35f6ef0729df2977c494f30d54da438ed0b98197a529bdb7bbe382

cameraToM9
a3d216769a59128825c44b5b69f7f9d9219dddb76c43e00bb462293afedf2bc9

m9CurvePixel
0c88877b5d50cf409bae84fe95e6e172184f2e7f0c39352b763fd5dafa7a9d5f

renderStripScalar
c157a252e4d29657ff000f3241c21a3c9cb89dfa57769b0579e6f22ac928faa0

orientCompletedStrip
534221e756b6d5af9e54312dfad441e25120d2941e288473d7b5aeda28faa51d
```

## Host parity validation

Two independent mapping checks passed.

Python partition/rotation parity:

```text
PERF3G ORIENTFUSE8A exact mapping parity PASS: 2646 partition/rotation cases
```

Standalone C++ parity:

```text
C++ ORIENTFUSE8A parity PASS 2646 cases
```

Cases cover:

- multiple block row counts including 383/384;
- odd/even source widths;
- 1/2/3/4/8/16 requested workers;
- 0/90/180/270 rotations;
- normalized negative/overflow rotation equivalents;
- unknown rotation fallback behavior.

The fused disjoint-subrange result was exactly equal to the original serial `orientCompletedStrip()` result in every case.

## Source guard

`perf3g_orientfuse8a_source_guard.py` passed and confirms:

- all six frozen function hashes above;
- exact `orientCompletedSubrange` seam exists;
- the PERF3G parallel block path has no serial post-worker `orientCompletedStrip` call;
- PERF3G diagnostics are present;
- JPEG quality remains 95.

## Diagnostics

New/updated fields:

```text
performanceForensics = PERF3G_ORIENTFUSE8A_EXIFASYNC1A_JPEGBUF64K1A_TC20LUMA8A_COLOR8A
performanceExperiment = retained_color8a_tc20luma8a_jpegbuf64k1a_exifasync1a_plus_exact_worker_orientation_fusion
nativeColorOrientationMode = orientfuse8a_worker_subranges_exact
nativeColorOrientationTimingMode = sum_worker_local_fused_copy_ns
nativeColorSerialOrientationPass = false
```

`nativeColorOrientationElapsedMsSum` now reports the **sum of worker-local fused copy time**. It is no longer a serial wall-time field. Critical wall impact is reflected by `nativeColorWorkerWallElapsedMsSum` and `fullColorRenderElapsedMs`.

## Expected device result

PERF3F latest frames showed approximately 24–31 ms of serial native orientation work. Fusing that work into eight existing workers should reduce full-color wall time by a portion of that amount; it will not necessarily remove all 24–31 ms because workers still perform the same exact memory movement and the slowest worker determines the fused wall.

This is deliberately a modest architectural test. A useful result would be approximately 15–25 ms lower full-color/render-worker time under comparable device load with no pixel/metadata/output regression.

## Device acceptance gate

Test one settled standalone frame and 4–5 rapid frames after cooling.

Require:

```text
performanceForensics contains PERF3G_ORIENTFUSE8A
nativeColorOrientationMode = orientfuse8a_worker_subranges_exact
nativeColorSerialOrientationPass = false
jpegQuality = 95
jpegExifAsyncAccepted = true
jpegExifSyncFallback = false
jpegExifFinalizeSuccess = true
jpegPublicationAfterExif = true
jpegSaved = true
dngSaved = true
rawFrameCloseOwner = M9PrimaryDngIO
```

Compare especially:

```text
fullColorRenderElapsedMs
nativeColorWorkerWallElapsedMsSum
nativeColorOrientationElapsedMsSum   # now worker-sum, not serial wall
nativeColorOutputCopyElapsedMsSum
directOrientedCommitElapsedMs
renderCoreElapsedMs
workerElapsedMs
```

Promotion requires correct output first. A timing win is not accepted if photographic/JPEG quality changes.


## Device validation — 2026-09-02

Test set:

- one settled standalone frame: `IMG_20260902_074512_1788331512058_00_M9_PRIMARY.json`;
- five completed rapid frames: `IMG_20260902_074612_1788331572050_00_M9_PRIMARY.json` through `IMG_20260902_074614_1788331574150_00_M9_PRIMARY.json`.

Correctness passed on all six frames:

```text
nativeColorOrientationMode = orientfuse8a_worker_subranges_exact
nativeColorSerialOrientationPass = false
jpegQuality = 95
jpegExifAsyncAccepted = true
jpegExifSyncFallback = false
jpegExifFinalizeSuccess = true
jpegPublicationAfterExif = true
jpegSaved = true
dngSaved = true
rawFrameCloseOwner = M9PrimaryDngIO
```

No EXIF or DNG preservation fallback occurred.

### Standalone PERF3G frame

```text
queue wait                       0 ms
worker                         862 ms
render core                    600 ms
full color                     300 ms
native color worker wall       233.45 ms
TC20                           149 ms
native TC20                    109 ms
JPEG payload                   207 ms
JPEG encoder CPU               177.97 ms
EXIF finalization off worker    35.30 ms
DNG save                       550 ms
```

### Five-frame rapid PERF3G medians

```text
queue wait                     693 ms
worker                         858 ms
render core                    644 ms
full color                     406 ms
native color worker wall       343.16 ms
worker-local orientation sum    26.18 ms
JNI output copy                  5.90 ms
Bitmap.setPixels commit         27 ms
OpenCV->Java color transfer     13.15 ms
JNI color input copy             5.11 ms
TC20                           177 ms
native TC20                    116 ms
meter transfer                  10 ms
TC20 native input copy           0.81 ms
JPEG payload                   171 ms
JPEG encoder CPU               150.34 ms
EXIF finalization off worker    36.59 ms
DNG save                       691 ms
```

Rapid queue waits were:

```text
0, 296, 693, 1285, 1557 ms
```

The five uploaded frames were all accepted/completed, but `admissionRejectCountSnapshot` progressed `0, 2, 4, 6, 8`, showing that additional shutter attempts were still rejected by QUEUE1B while the bounded render allowance was full. Queue policy remains correct; do not widen it merely to hide processing latency.

### PERF3F comparison

Prior PERF3F burst medians:

```text
worker                         1072 ms
render core                     761 ms
full color                      452 ms
native color worker wall        353.79 ms
queue wait                     1367 ms
```

PERF3G burst medians:

```text
worker                          858 ms
render core                     644 ms
full color                      406 ms
native color worker wall        343.16 ms
queue wait                      693 ms
```

The large whole-frame improvement is partly scene/device/JPEG-load variability and must not all be credited to ORIENTFUSE8A. The cleaner orientation-specific signal is that the old serial post-worker orientation pass is absent while native color worker wall fell by about 10.6 ms median. That is consistent with a modest overlap/distribution win from fusing the same exact copy into the existing workers.

### Promotion decision

```text
ORIENTFUSE8A = RETAIN / PROMOTE
```

Reasons:

1. all device correctness gates passed;
2. no photographic/JPEG/exposure math changed;
3. no serial orientation pass remains;
4. exact host parity was already proven across 5,292 Python/C++ mapping cases combined;
5. device timing shows a modest plausible native-color critical-wall improvement with no regression.

The next quality-safe target is input-side duplicate copying before considering Android Bitmap direct writes.
